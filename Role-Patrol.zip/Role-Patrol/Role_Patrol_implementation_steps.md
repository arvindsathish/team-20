# T20 Role Patrol — Hackathon Implementation & Deployment Guide



> **Project Name:** `T20_Role_Patrol`  

> **Target Audience:** Hackathon Team 20 (4–5 Members)  

> **Environment:** Pre-provisioned Hackathon Lab Subscription **`gmfdev-hackathon-team020-innovation`** (`0b461eb3-6154-44c4-bbc1-e54179886f8d`), Entra tenant `gmfdev.onmicrosoft.com` (`1c3bd3e8-1b6d-423a-a3e4-813b1f3f6619`), region `centralus`. The hackathon committee already created the network, SQL, AI Search, Key Vault, monitoring and App Service foundation (see **Section 1A**). **This guide only creates what is missing.**  

> **Working Directory:** the root of your local clone of the `team-20` repo (e.g. `...\Hackathon\team-20-main`). All relative paths `.\datasets\`, `.\scripts\`, `.\sql\`, `.\templates\` resolve here. **You must be on the lab network** (Cloud PC / VPN) — SQL, AI Search, Key Vault and App Service endpoints are private-only (Section 1A).  

> **Reuse-First Rule:** Reuse the committee-provisioned resources (SQL server + database, AI Search service, Linux App Service plan, VNet/private DNS, Log Analytics/App Insights) wherever Section 1A marks them **Reuse**. Create only the items marked **Create**, in the resource groups listed there. Never delete, resize, or reconfigure committee resources other than what this guide states, and never re-enable public network access on them.  

> **Resource Naming Standard:** Committee resources keep their names (`gmfdev-hackathon-team020-*`). New Azure resources follow the **same committee convention** (`gmfdev-hackathon-team020-<purpose>`). Entra objects (users, groups, app registrations) and the dataset prefix keep the **`t020_`** prefix (`t020-` where Azure forbids underscores) so they are identifiable in the shared `gmfdev` tenant.  

> **Zero Hardcoding / Cheating Rule:** 100% genuine data flow. All metrics, role rankings, What-If simulations, and evidence records are calculated dynamically by the Azure SQL engine from the 8 dataset CSVs in `.\datasets\`. Zero hardcoded counts, zero pre-canned metrics.  

> **Lab Resources & Quotas:** Verified against the live subscription: the signed-in user is a member of `gmfdev-hackathon-team020-innovation-owner` (subscription **Owner**, SQL Entra admin, Search Service/Index Contributor). All required resource providers are already registered. The SQL database is **Standard S0 (10 DTU), not Serverless**; AI Search is **Basic** (semantic ranker on the free tier); Azure Policy is limited to the default ASC initiative (no deny policies found).  

> **Dataset:** 8 Production-grade synthetic CSV files located in `.\datasets\` (500 employees, 75 business roles, 40 applications, 250 entitlements, 900 role-entitlements, 650 assignments, 175 JML events, 600 access request tickets).  

> **Estimated Total Execution Time:** 40–55 minutes (with parallel track execution; SQL, Search and resource-group creation steps are removed, private endpoint and ADF managed-network steps are added).  



---



## 1A. Lab Baseline — What the Hackathon Committee Already Provisioned

The subscription was inspected live (Azure CLI) before this guide was adapted. **Re-run the verification script in Step 0.1 before you start** — the committee may change the baseline.

| Existing Resource | Resource Group | Verified State | Decision for Role Patrol |
|---|---|---|---|
| Spoke VNet `gmfdev-hackathon-team020-spoke-vnet` + 41 Private DNS zones (SQL, Search, `azurewebsites.net`, Data Factory, Key Vault, …) | `gmfdev-hackathon-team020-network-rg` | Subnets: `private-endpoints-subnet` (10.0.58.64/26), `vnet-integration-subnet` (10.0.58.128/26, delegated `Microsoft.Web/serverFarms`), `appservice-functions-subnet` (10.0.59.64/26, delegated `Microsoft.Web/serverFarms`), `cloudpc-subnet`. Both web subnets are unused. | **Reuse** — outbound VNet integration and inbound private endpoints for the web/API apps. |
| Azure SQL Server `gmfdev-hackathon-team020-sql` | `gmfdev-hackathon-team020-sql-rg` | **Entra-only auth**, admin = group `gmfdev-hackathon-team020-innovation-owner`, **public network access Disabled**, private endpoint `...-sql-pe` (10.0.58.94), system-assigned identity, no firewall rules. | **Reuse.** Replaces `t020-sql-<suffix>`. No firewall rules are created. |
| SQL Database `gmfdev-hackathon-team020-sqldb` | `gmfdev-hackathon-team020-sql-rg` | **Standard S0 (10 DTU)**, Online, **0 tables** (empty). Signed-in user is `db_owner` through the owner group. | **Reuse.** Replaces `t020_rolepatrol`. Optionally scale to S1/S2 (Step B1). |
| Azure AI Search `gmfdev-hackathon-team020-foundry-search` | `gmfdev-hackathon-team020-foundry-rg` | **Basic**, public access Disabled, private endpoint, API key **or** Entra auth, **0 indexes**, semantic ranker (free tier). | **Reuse.** Replaces `t020-srch-<suffix>`. Create only the `ticket-text` index; do not touch other indexes. |
| App Service Plan `gmfdev-hackathon-team020-linux-asp` | `gmfdev-hackathon-team020-linux-app-rg` | **Linux P1v3**, no apps deployed. | **Reuse** — hosts the Role Patrol web portal and the two API gateways. |
| Key Vault `gmfdevhackteam020akv` | `gmfdev-hackathon-team020-keyvault-rg` | RBAC mode, public access Disabled, private endpoint. | Optional — store `owner-credentials` instead of a local file. |
| Log Analytics `gmfdev-hackathon-team020-spoke-law`, App Insights `gmfdev-hackathon-team020-spoke-appinsights`, AMPLS | `gmfdev-hackathon-team020-monitoring-rg` | Present, private link scope. | Optional — send web/API app logs here. |
| Foundry / Azure OpenAI / Cosmos DB / Databricks / Copilot Studio (`20RolePatrol`) / Network Watcher | various | Present. | **Not used** by this guide. Do not modify. |
| Azure Data Factory, Logic Apps, Static Web Apps, Web Apps | — | **None exist.** | **Create** ADF and the Web Apps; Logic Apps and SWA are **replaced** (see decisions below). |

### Design Decisions Forced by the Lab Network

| # | Lab constraint | Original guide assumption | Adapted approach |
|---|---|---|---|
| D1 | SQL, Search, Key Vault and App Service endpoints are **private-only** (public access Disabled). | SQL firewall rules for laptop IP and `AllowAllWindowsAzureIps`; public Search/SQL. | No firewall rules. All data-plane work runs from a machine **inside the lab network** (Cloud PC / VPN). Never enable public access. |
| D2 | **Consumption Logic Apps cannot reach private-only SQL/Search** (the managed SQL connector uses public Azure connector IPs). Logic Apps Standard needs a Windows plan; the committee plan is Linux. | 4 Consumption Logic Apps (`t020_la_*`) as API gateways. | **Two Linux Web Apps on the existing plan** (`...-rp-api-a`, `...-rp-api-b`) with VNet integration and a system-assigned managed identity act as the OAuth gateways. Same contract and same SQL procedure (`api.usp_Gateway`). |
| D3 | Static Web Apps (Free) is internet-hosted and cannot be network-isolated with the lab. | SWA hosts the SPA. | A third Web App (`...-rp-web`) on the same plan hosts `web/dist`, reachable through a private endpoint. |
| D4 | ADF must reach private SQL. | ADF with default Azure IR. | ADF uses a **Managed Virtual Network IR + managed private endpoint** to the SQL server; Owner approves the pending connection. |
| D5 | Collector/Shell Logic Apps cannot write to private SQL. | Collector Logic App with Graph `GroupMember.Read.All`. | **Removed.** Live Entra collection is run by `Invoke-EntraCollection.ps1` from a lab workstation (Step 5.1). Shell was an empty placeholder. |
| D6 | The `gmfdev.onmicrosoft.com` tenant is **shared**; Graph writes may be limited by Conditional Access (CAE location challenge seen on this subscription). | Dedicated tenant. | Keep the `t020_` prefix on all Entra objects, verify Entra rights in Step 0.1, and see Troubleshooting Q7. |

**Resource groups used.** **No new resource group is created.** Data Factory goes in the committee's `gmfdev-hackathon-team020-sql-rg`, and the web apps and their private endpoints go in `gmfdev-hackathon-team020-linux-app-rg`. Because resources live in several RGs, `names.json` carries **one RG field per resource** (Step 0.2).

---

## 1. Master Azure Components & Services Blueprint



To build `T20_Role_Patrol` on the pre-provisioned lab, the following components are **reused** or **created**. Committee resources keep their `gmfdev-hackathon-team020-*` names; new Azure resources follow the same convention; Entra objects keep the `t020_` prefix:



| Component / Service Name | Azure Service Type | Creation Tool / Mechanism | Assigned Track & Owner | Purpose in `T20_Role_Patrol` | Sizing, Tier & Key Configuration |
|---|---|---|---|---|---|
| **`gmfdev-hackathon-team020-sql-rg`** (**Reuse**) | Resource Group | Committee-provisioned | **Phase 0:** Team Lead | Holds Data Factory (`ResourceGroup` in `names.json`). Web apps go in the committee's `gmfdev-hackathon-team020-linux-app-rg`. No new RG is created. | Region: `centralus`. |
| **`gmfdev-hackathon-team020-sql`** (**Reuse**) | Azure SQL Server | Committee-provisioned — **verify only** | **Track B:** Member 2 | Host for core relational ledger, engine procedures, and security principal maps. | Entra-only auth (already enabled), **public access Disabled**, reached via private endpoint. No firewall rules are added. |
| **`gmfdev-hackathon-team020-sqldb`** (**Reuse**) | Azure SQL Database | Committee-provisioned — schemas deployed by Track B | **Track B:** Member 2 | Stores 8 dataset CSV tables (`src.*`), governance engine (`core.*`), casework audit (`casework.*`), and search views (`search.*`). | Standard S0 (10 DTU), currently empty. Optional: scale to S1/S2 for faster assessment runs. Not serverless — no auto-pause. |
| **`gmfdev-hackathon-team020-adf`** (**Create**) | Azure Data Factory | Azure CLI (`az datafactory create`) + ARM REST | **Track C:** Member 3 | Autonomous orchestrator for data ingestion and role friction assessment. | V2 Data Factory with System-Assigned Managed Identity, **Managed Virtual Network IR** and a **managed private endpoint** to the SQL server. |
| **`RolePatrolAssessment`** | ADF Pipeline | Azure CLI / REST API (`az datafactory pipeline create`) | **Track C:** Member 3 | Executes `core.usp_Ingest` and `core.usp_Assess` stored procedures over the 600 tickets. | Anchored to `@BusinessAsOf = '2026-10-01T12:00:00'` to cleanly envelop the dataset. |
| **`gmfdev-hackathon-team020-foundry-search`** (**Reuse**) | Azure AI Search | Committee-provisioned — index created by script | **Track D:** Member 4 | Natural-language semantic search engine for the 600 access request tickets. | **Basic SKU**, public access Disabled (private endpoint), semantic ranker available (free tier). Shared with Foundry — only the `ticket-text` index is created. |
| **`ticket-text`** | AI Search Index | REST API (`Invoke-RestMethod`) | **Track D:** Member 4 | Reverse-index mapping ticket complaint text, ticket IDs, types, and context codes. | Fields: `ticketId`, `ticketText`, `ticketType`, `contextCode`. |
| **`gmfdev-hackathon-team020-rp-web`** (**Create**, replaces Static Web App) | Azure Web App (Linux, Node 20) on `gmfdev-hackathon-team020-linux-asp` | Azure CLI (`az webapp create`) | **Track D:** Member 4 | Hosts the responsive Single Page Application (SPA) governance portal. Hostname saved dynamically to `names.json` as `WebUrl`. | Existing P1v3 plan, VNet integration, private endpoint in `private-endpoints-subnet`, zip-deployed `web/dist`. |
| **`gmfdev-hackathon-team020-rp-api-a`** (**Create**, replaces Logic App `t020_la_api_a`) | Azure Web App (Linux, Node 20) — API gateway | Azure CLI (`az webapp create`) | **Track C:** Member 3 | Secured API Gateway for **Owner A (US lead, `OwnerAGid` in `names.json`)**. Invokes `api.usp_Gateway` and Azure AI Search. | Existing plan, VNet integration, private endpoint, system-assigned MSI mapped to a SQL user with binary SID, Entra v2 token validation (`iss/aud/tid/oid/azp/scp`). |
| **`gmfdev-hackathon-team020-rp-api-b`** (**Create**, replaces Logic App `t020_la_api_b`) | Azure Web App (Linux, Node 20) — API gateway | Azure CLI (`az webapp create`) | **Track C:** Member 3 | Secured API Gateway for **Owner B (Canada lead, `OwnerBGid` in `names.json`)**. Invokes `api.usp_Gateway` and Azure AI Search. | Same configuration as API-A, locked to Owner B's object ID. |
| ~~`t020_la_collect_<suffix>`, `t020_la_shell_<suffix>`~~ (**Removed**) | — | — | — | Collector/Shell Logic Apps cannot write to private-only SQL. Live Entra collection is performed by `Invoke-EntraCollection.ps1` (Step 5.1). | — |
| **`t020_RolePatrol-API-<suffix>`** | Entra App Registration | Azure CLI (`az ad app create`) | **Track A:** Member 1 | OAuth 2.0 Resource Server exposing the backend governance API. | Exposes delegated scope `RolePatrol.Access`, requests token v2. |
| **`t020_RolePatrol-Browser-<suffix>`** | Entra App Registration | Azure CLI (`az ad app create`) | **Track A:** Member 1 | OAuth 2.0 Client application representing the browser Single Page App. | Configured as SPA redirect URI (`https://<web-app-host>/bridge.html`), authorized for `RolePatrol.Access`. |
| **Entra Users & Security Groups** | Entra ID Directory | PowerShell Script (`Import-DirectoryFromDataset.ps1`) | **Track A:** Member 1 | Live identity directory reflecting GM Financial cohort employees and entitlement groups. | 30 active employees (including the two demo leads `OwnerAGid` & `OwnerBGid`), 16 entitlement security groups (`ENT0001`–`ENT0016`). Full 500-employee cohort in SQL. |



---



## 2. Parallel Team Delegation & Synchronization Gates



`T20_Role_Patrol` is structured into **four parallel tracks** following a shared bootstrap phase. Each track is assigned to a specific team member, bounded by **4 Synchronization Gates** to eliminate race conditions and configuration mismatches.



```mermaid
flowchart TD
    subgraph P0["Phase 0: Environment Setup — 5 min"]
        RG["Verify Lab Baseline & Use Existing Resource Groups (no new RG)"]
        RP["Confirm Resource Providers (already registered)"]
        REG["Generate Shared Registry (names.json)"]
    end

    subgraph TrackA["Track A: Identity & Security — 10 min"]
        A1["A1: Ingest/Verify Synthetic Entra Directory"]
        A2["A2: Register API App & Expose RolePatrol.Access Scope"]
        A3["A3: Register SPA App & Grant Admin Consent"]
    end

    subgraph TrackB["Track B: Data & Engine — 15 min"]
        B1["B1: Verify Existing SQL Server & DB (gmfdev-hackathon-team020-sql / -sqldb)"]
        B2["B2: Verify Private Connectivity (No Firewall Rules)"]
        B3["B3: Deploy Schemas (01-07) & Ingest 8 CSV Datasets"]
    end

    subgraph TrackC["Track C: Orchestration & Compute — 15 min"]
        C1["C1: Azure Data Factory (Managed VNet + Managed Private Endpoint) & Assessment Pipeline (2026-10-01)"]
        C2["C2: 3 Web Apps (web + API A/B) on Existing Linux Plan with Managed Identities"]
        C3["C3: Private Endpoints + VNet Integration for Web Apps"]
        C4["C4: Provision SQL Managed Identity Users & Permissions"]
    end

    subgraph TrackD["Track D: Search & Web Portal — 15 min"]
        D1["D1: Existing Azure AI Search (Basic) — Create ticket-text Index & Grant MSI Reader"]
        D2["D2: Resolve Web App Hostnames (WebUrl) into names.json"]
        D3["D3: Register Web App Redirect URI in Entra ID"]
        D4["D4: Deploy API Gateways (Deploy-AppServiceGateway.ps1)"]
        D5["D5: Build Zero-Dependency Web Artifacts (npm run build)"]
        D6["D6: Deploy Production Web Portal to Web App (zip deploy)"]
    end

    subgraph P5["Phase 5: Verification & Live Demo — 10 min"]
        V1["Trigger Live Entra Collection & ADF Assessment Pipeline"]
        V2["Execute Automated Validation Suite (23 Core Contracts)"]
        V3["Present 4-Step GM Financial Pitch & Live Portal Demo"]
    end

    P0 --> TrackA
    TrackA --> TrackB
    TrackB --> TrackC
    TrackC --> TrackD
    TrackD --> P5
```



---



### Team Roles & Ownership Matrix



| Track | Owner / Role | Deliverables & Responsibilities | Upstream Dependencies | Downstream Consumers |
|---|---|---|---|---|
| **Phase 0** | **Team Lead** | Verify lab baseline & access (incl. MFA step-up), confirm provider registrations, generate `names.json` pointing at the existing resource groups, distribute config to team. | Azure Subscription access (owner group), lab network access. | All Members. |
| **Track A** | **Member 1 (Identity & Security)** | Provision Entra users & groups from `EMPLOYEE_IDENTITY.csv` & `ENTITLEMENT_CATALOG.csv`, `identity-map.sql`, API & SPA App Registrations (`t020_RolePatrol-*`), Graph API permissions. | `names.json` from Phase 0, Dataset CSVs. | Member 2 (SQL map), Member 3 & 4 (App IDs). |
| **Track B** | **Member 2 (Database & Engine)** | Verify existing SQL server `gmfdev-hackathon-team020-sql` and DB `gmfdev-hackathon-team020-sqldb`, Schemas 01–09, execute `Import-HackathonDatasets.ps1` for 8 CSVs, MSI SQL users & Least-Privilege grants. | `names.json`, `identity-map.sql` from Track A, MSI IDs from Track C. | Member 3 (ADF/API apps), Member 4 (Search). |
| **Track C** | **Member 3 (Backend & Orchestration)** | Azure Data Factory (`gmfdev-hackathon-team020-adf`) with managed private endpoint, Assessment Pipeline (anchored to `2026-10-01`), API Web Apps A/B on the existing plan, private endpoints/VNet integration, token-validating gateway. | `names.json`, SQL Server from Track B, API Client ID from Track A. | Member 2 (MSI IDs for SQL), Member 4 (API URLs). |
| **Track D** | **Member 4 (Frontend & Search)** | `ticket-text` index on the existing AI Search service (600 tickets), web portal Web App (`gmfdev-hackathon-team020-rp-web`), compile MSAL bundles, publish live web portal. | `names.json`, Web URL for Track A, API URLs from Track C, SQL from Track B. | Phase 5 (Live Portal). |
| **Phase 5** | **Whole Team** | Run collection, trigger assessment, run validation checks, rehearse GM Financial judge presentation. | All tracks deployed. | Hackathon Judges. |



---



### Azure Resource Naming Architecture for `t020`



> [!IMPORTANT]

> **Azure Syntax Compliance:** Committee resources already comply with Azure naming rules. New resources reuse the committee convention `gmfdev-hackathon-team020-<purpose>` (lowercase, hyphens only), which is valid for Web Apps and Data Factory. Entra objects keep the `t020_` prefix.



| Azure Resource Type | Name Used in this Lab | Origin |
|---|---|---|
| **Resource Group (Data Factory)** | `gmfdev-hackathon-team020-sql-rg` | Committee (reuse) |
| **Resource Group (web apps)** | `gmfdev-hackathon-team020-linux-app-rg` | Committee |
| **Azure SQL Server** | `gmfdev-hackathon-team020-sql.database.windows.net` | Committee (reuse) |
| **Azure SQL Database** | `gmfdev-hackathon-team020-sqldb` | Committee (reuse) |
| **Azure AI Search** | `gmfdev-hackathon-team020-foundry-search` (RG `gmfdev-hackathon-team020-foundry-rg`) | Committee (reuse) |
| **Azure Data Factory** | `gmfdev-hackathon-team020-adf` | Created by this guide |
| **Web Portal Web App** | `gmfdev-hackathon-team020-rp-web` | Created by this guide (replaces SWA) |
| **API Gateway (ApiA)** | `gmfdev-hackathon-team020-rp-api-a` | Created by this guide (replaces Logic App) |
| **API Gateway (ApiB)** | `gmfdev-hackathon-team020-rp-api-b` | Created by this guide (replaces Logic App) |
| **Entra API App** | `t020_RolePatrol-API-<suffix>` | Created by this guide |
| **Entra Browser SPA** | `t020_RolePatrol-Browser-<suffix>` | Created by this guide |
| **Entra users / groups** | `<Prefix>-GIDxxxx@<tenant domain>`, `ENT0001`–`ENT0016` groups with `<Prefix>` | Created by this guide |

---

### Cross-Track Hand-Off Exchange Sheet

Use this cheat sheet to record and exchange dynamic values between team members during the hackathon:

| Variable Name | Generated By | Consumed By | t020 Value / Description |
|---|---|---|---|
| `$SUFFIX` | Team Lead (Phase 0) | All Members | e.g., `9a2f1b` (6-char unique hex suffix) |
| `$names.ResourceGroup` | Team Lead (Phase 0) | Member 3 | `gmfdev-hackathon-team020-sql-rg` (Data Factory). Other RGs are in `SqlResourceGroup`, `SearchResourceGroup`, `AppResourceGroup`, `NetworkResourceGroup`. |
| `$names.SqlServer` | Team Lead (Phase 0) | Member 2, 3, 4 | `gmfdev-hackathon-team020-sql` (reuse; resolves to a private IP) |
| `identity-map.sql` | Member 1 (Track A) | Member 2 (Track B) | Generated SQL inserts for `src.IdentityMap` & `src.GroupMap` |
| `$API_CLIENT_ID` | Member 1 (Track A) | Member 3, 4 | Entra Application (Client) ID of `t020_RolePatrol-API-<suffix>` |
| `$SPA_CLIENT_ID` | Member 1 (Track A) | Member 3, 4 | Entra Application (Client) ID of `t020_RolePatrol-Browser-<suffix>` |
| `$OWNER_A_OBJ_ID` | Member 1 (Track A) | Member 4 (Track D) | Entra User Object ID of Owner A (US lead, `names.OwnerAGid`) — from `identity-map.csv` |
| `$OWNER_B_OBJ_ID` | Member 1 (Track A) | Member 4 (Track D) | Entra User Object ID of Owner B (Canada lead, `names.OwnerBGid`) — from `identity-map.csv` |
| `$ADF_MSI_APP_ID` | Member 3 (Track C) | Member 2 (Track B) | ADF Managed Identity Application ID (for SQL User) |
| `$API_A_MSI_APP_ID` | Member 3 (Track C) | Member 2 (Track B) | API-A Web App MSI Application ID (for SQL User) |
| `$API_B_MSI_APP_ID` | Member 3 (Track C) | Member 2 (Track B) | API-B Web App MSI Application ID (for SQL User) |
| `$WEB_URL` | Member 4 (Track D) | Member 1, 3, 4 | Private Web App hostname (e.g. `https://gmfdev-hackathon-team020-rp-web.azurewebsites.net`) saved into `names.json` (`WebUrl`) in Step D2 |
| `$API_A_URL` | Member 3 (Track C) | Member 4 (Track D) | API-A Web App URL (e.g. `https://gmfdev-hackathon-team020-rp-api-a.azurewebsites.net/api/gateway`) |
| `$API_B_URL` | Member 3 (Track C) | Member 4 (Track D) | API-B Web App URL (e.g. `https://gmfdev-hackathon-team020-rp-api-b.azurewebsites.net/api/gateway`) |

### Recommended Build Gate & Handoff Sequence
To guarantee zero deadlocks between tracks and ensure all configuration artifacts (`names.json`, `web/config.json`) are populated without manual intervention:
1. **Gate 0 (Team Lead):** Verify the lab baseline (Step 0.1), generate `names.json` with a fresh `$SUFFIX` (Entra objects only), and confirm the existing resource groups and MFA step-up (Step 0.4).
2. **Gate 1 (Track D early start):** Member 4 creates the web portal Web App (`Step D2`), retrieves `$WEB_URL`, and saves `WebUrl` into `names.json`.
3. **Gate 2 (Track A & Track B in parallel):** 
   - Member 1 runs directory import (`Step A1`), outputs `identity-map.sql`, runs app registrations (`Step A2-A4` or `Deploy-Entra.ps1` using `WebUrl`), and writes `ApiClientId` / `SpaClientId` to `names.json`.
   - Member 2 verifies the existing SQL server/database and private connectivity (`Step B1-B2`) and ingests schemas 01–07 & datasets (`Step B3`).
4. **Gate 3 (Track C Web Apps, Data Factory & Managed Identities):**
   - Member 3 deploys Data Factory (`Step C1`) and the API Web Apps with private networking (`Step C2-C3`).
   - Member 2 executes `Step C4` to provision SQL Managed Identity users (`ApiA`, `ApiB`, `Factory`) and applies final permissions (`08_portfolio_access.sql`, `09_enable_evaluator_actions.sql`).
   - Member 3 runs `Deploy-AppServiceGateway.ps1` (`Step D4`), which consumes `ApiClientId`, `SpaClientId`, and `WebUrl` from `names.json` to deploy the secured OAuth gateways and auto-populates `web/config.json`.
5. **Gate 4 (Search & Web Portal Build):**
   - Member 4 runs `Deploy-Search.ps1` (`Step D1`) against the existing search service, directly ingesting the 600 semantically enriched tickets into `ticket-text`.
   - Member 4 builds the SPA with `npm.cmd ci && npm.cmd run build` (`Step D5`) and deploys to the web app (`Step D6`).
6. **Gate 5 (Verification & Live Demo):** Whole team executes live Entra collection (`Step 5.1`), ADF assessment (`Step 5.1`), automated assertions (`Step 5.2`), and rehearses the demo script (`Step 5.3`).



---



## 3. Dataset Blueprint & Schema Mapping Specifications



The dataset in `.\datasets\` provides realistic enterprise identity, access, and ticketing data from GM Financial cohorts across US, Canada, and Mexico:



| File Name | Rows | Key Columns / Entity Mappings |
|---|---|---|
| `EMPLOYEE_IDENTITY.csv` | 500 | GID (GID0001-0500), Name, Email, Title, Cost Center, Business Group |
| `BUSINESS_ROLE_MASTER.csv` | 75 | Business_Role_ID (BR0001-0075), Title, Cost Center, Role_Owner_GID |
| `APPLICATION_MASTER.csv` | 40 | Application_ID (APP001-040), Name, Category (Reporting, Ops, etc.) |
| `ENTITLEMENT_CATALOG.csv` | 250 | Entitlement_ID (ENT0001-0250), Application_ID, Name, Access_Level |
| `ROLE_ENTITLEMENTS.csv` | 900 | Business_Role_ID, Entitlement_ID, Required_Flag, Gap_Category |
| `ROLE_ASSIGNMENTS.csv` | 650 | Assignment_ID (ASN0001-0650), GID, Business_Role_ID, Status, Dates |
| `JML_EVENTS.csv` | 175 | JML_Event_ID (JML0001-0175), GID, Event_Type (Joiner/Mover/Leaver) |
| `ACCESS_REQUEST_TICKETS.csv` | 600 | Ticket_ID (TKT0001-0600), GID, Business_Role_ID, Entitlement_ID, Status |

> [!NOTE]
> The dataset spec names the tickets file `ACCESS_REQUEST_TICKETS.csv`; the lab dataset in `.\datasets\` ships it as `MOCK_ACCESS_TICKETS.csv` (same 13 columns, 600 rows). The scripts accept **either** name (the spec name wins if both exist), so no rename or copy is needed.



### 3.1 Critical Schema Alignments for this Dataset



1. **Employee ID Format (`GID0001`–`GID0500`):**

   * The original mock schema used `char(4)` for `EmployeeId`.

   * The dataset uses `GID0001` (7 characters). The automated ETL script `Import-HackathonDatasets.ps1` dynamically adjusts `EmployeeId` across all tables to `varchar(16)`, ensuring zero truncation errors.

2. **Designated Role Owners (derived from the data, not hard-coded):**

   * `scripts\Select-RoleOwners.ps1` (Step 0.2b) picks, per country, the owner of the role with the most post-transfer friction tickets and records them in `names.json`:

   * **Owner A (US Lead):** `OwnerAGid` / `OwnerAName` / `OwnerARoleId` — currently **`GID0167` Kavisen Rynstead**, role **`BR0065`** (Application Access Liaison, GM Financial US).

   * **Owner B (Canada Lead):** `OwnerBGid` / `OwnerBName` / `OwnerBRoleId` — currently **`GID0300` Nerivo Yalcrest**, role **`BR0013`** (Governance Controls Specialist, GM Financial Canada).

   * Web API-A is mapped to Owner A, and Web API-B is mapped to Owner B.

3. **Temporal Anchoring:**

   * In `ACCESS_REQUEST_TICKETS.csv` (shipped in the lab as `MOCK_ACCESS_TICKETS.csv`) and `JML_EVENTS.csv`, event and ticket timestamps span `2025-01-01` to `2026-10-01` (verified: tickets `2025-01-01`–`2026-10-01`, JML events `2025-01-01`–`2026-09-25`).

   * When invoking `core.usp_Assess`, `@BusinessAsOf` must be set to `'2026-10-01T12:00:00'` (or `2026-10-02`) so no tickets are considered future events.

4. **Zero-Cheating / Pure Engine Execution:**

   * No metric is hardcoded or mocked in frontend code.

   * Friction scores, confidence intervals, role rankings, and What-If simulations are computed live by `core.usp_Assess` and `core.usp_WhatIf` directly against the 600 tickets and 175 JML events.



---



## 4. Pre-requisites & Local Environment Setup



### 4.1 Azure Subscription & IAM Role Requirements

Before beginning, ensure your team's signed-in Azure account has:

1. **Azure Subscription Role:** In this lab, `Owner` is granted through membership of the Entra group **`gmfdev-hackathon-team020-innovation-owner`** (also the SQL Entra admin and Search Service/Index Contributor). Owner is required to approve the ADF managed private endpoint and to assign roles to Managed Identities. Members of `gmfdev-hackathon-team020-innovation-contributor` cannot assign roles — ask a group member to run Steps C3/C4/D1 role assignments.

2. **Microsoft Entra ID Role:** Default users in the `gmfdev` tenant **can** register applications and create security groups. **Creating users, and granting admin consent for `RolePatrol.Access`, need a directory role** (`User Administrator` / `Application Administrator` or higher). This could not be verified from automation (Graph returned a Conditional Access/CAE challenge) — confirm in Step 0.1 and request the role from the committee if missing.

3. **Network Access:** Run every command from a machine on the lab network (Cloud PC in `cloudpc-subnet` or VPN). Verify with Step 0.1 that `gmfdev-hackathon-team020-sql.database.windows.net` resolves to a private `10.0.x.x` address and TCP 1433 is reachable.



### 4.2 Local Developer Workstation Tools

Each team member must run these commands in an elevated PowerShell terminal:



```powershell
# 1. Install CLI tools via Windows Package Manager

winget install --id Microsoft.PowerShell --exact --source winget

winget install --id Microsoft.AzureCLI --exact --source winget

winget install --id OpenJS.NodeJS.LTS --exact --source winget

winget install --id Git.Git --exact --source winget

# 2. Install SQL Server PowerShell module (required for token-based SQL deployment)

Install-Module -Name SqlServer -Scope CurrentUser -AllowClobber -Force

# 3. Azure CLI extension for Data Factory (no extensions are installed by default; preview extensions are blocked by default)
az config set extension.dynamic_install_allow_preview=true
az extension add --name datafactory --allow-preview true --upgrade
```

> [!NOTE]
> `SqlServer` is **not** installed on the lab image checked (no `Invoke-Sqlcmd`/`sqlcmd`). Node.js (v26) and npm are present. If `Install-Module` is blocked, see Troubleshooting Q6.



### 4.3 Tooling Verification Script

Run this snippet to ensure all local tools are ready:



```powershell
Write-Host "--- Checking Tooling Versions ---" -ForegroundColor Cyan

Write-Host "PowerShell: $($PSVersionTable.PSVersion)"

Write-Host "Azure CLI:  $((az version --output json | ConvertFrom-Json).'azure-cli')"

Write-Host "Node.js:    $(node --version)"

Write-Host "npm:        $(npm.cmd --version)"

Write-Host "SqlServer:  $((Get-Module -ListAvailable SqlServer | Select-Object -First 1).Version)"

Write-Host "Tooling validation complete!" -ForegroundColor Green
```



---



## 5. Phase 0: Master Environment Setup (Team Lead)



**Owner:** Team Lead  

**Duration:** ~10 minutes  

**Goal:** Verify the committee-provisioned lab baseline and your access, create the dedicated Role Patrol Resource Group for new resources, and export the global `names.json` registry.



### Step 0.1: Login, Set Context & Verify the Lab Baseline
```powershell
# If the Windows account picker fails ("logon session does not exist"), use the options below the script.
az login --tenant "gmfdev.onmicrosoft.com"

$SUB_ID = "0b461eb3-6154-44c4-bbc1-e54179886f8d"
az account set --subscription $SUB_ID
$sub = az account show --output json | ConvertFrom-Json

Write-Host "Connected to Subscription: $($sub.name) ($($sub.id))" -ForegroundColor Green

# 1. Committee resources must exist
az resource list --subscription $SUB_ID --query "[?contains('Microsoft.Sql/servers Microsoft.Sql/servers/databases Microsoft.Search/searchServices Microsoft.Web/serverFarms Microsoft.Network/virtualNetworks', type)].{rg:resourceGroup,name:name,type:type}" -o table

# 2. SQL must resolve privately and be reachable (expect 10.0.x.x and True)
Resolve-DnsName "gmfdev-hackathon-team020-sql.database.windows.net" | Select-Object Name, Type, IPAddress
Test-NetConnection "gmfdev-hackathon-team020-sql.database.windows.net" -Port 1433 -InformationLevel Quiet

# 3. Confirm you are a member of the owner group (Owner is inherited through it). Expect: true
$MY_ID = az ad signed-in-user show --query id -o tsv
az ad group member check --group "gmfdev-hackathon-team020-innovation-owner" --member-id $MY_ID --query value -o tsv
# Confirm the group really holds Owner on the subscription (lists the group; $SUB_ID must be set by the lines above - run this whole step in one session)
az role assignment list --subscription $SUB_ID --scope "/subscriptions/$SUB_ID" --role Owner --query "[?principalName=='gmfdev-hackathon-team020-innovation-owner'].principalName" -o tsv

# 4. Confirm Entra rights (needs a directory role to create users / grant consent)
az rest --method GET --uri "https://graph.microsoft.com/v1.0/me/transitiveMemberOf/microsoft.graph.directoryRole?`$select=displayName" --query "value[].displayName" -o tsv
```

> [!TIP]
> **Login options:** (a) `az login` in a normal Windows PowerShell session. (b) If the broker fails, run `az config set core.enable_broker_on_windows=false` and then `az login --use-device-code --tenant "gmfdev.onmicrosoft.com"`. (c) If Graph returns `InteractionRequired ... LocationConditionEvaluationSatisfied`, run `az logout; az login` from a machine on the lab network (Troubleshooting Q7).



### Step 0.2: Generate Shared Naming Registry for t020 (`names.json`)

```powershell
# Define target region and a unique 6-character suffix (used ONLY for Entra objects and the dataset prefix)

$LOCATION = "centralus"

$SUFFIX   = [guid]::NewGuid().ToString('N').Substring(0, 6) # e.g. "9a2f1b"

$PREFIX   = "t020_$SUFFIX"

$NetRG    = "gmfdev-hackathon-team020-network-rg"

$Names = [pscustomobject]@{

    Prefix              = $PREFIX

    Suffix              = $SUFFIX

    Location            = $LOCATION

    SubscriptionId      = $sub.id

    TenantId            = $sub.tenantId

    # Resource groups (one per resource - committee RGs + the new Role Patrol RG)

    ResourceGroup       = "gmfdev-hackathon-team020-sql-rg"   # Data Factory (existing committee RG)

    SqlResourceGroup    = "gmfdev-hackathon-team020-sql-rg"

    SearchResourceGroup = "gmfdev-hackathon-team020-foundry-rg"

    AppResourceGroup    = "gmfdev-hackathon-team020-linux-app-rg"

    NetworkResourceGroup= $NetRG

    VNet                = "gmfdev-hackathon-team020-spoke-vnet"

    PeSubnet            = "private-endpoints-subnet"

    AppSubnet           = "vnet-integration-subnet"

    AppServicePlan      = "gmfdev-hackathon-team020-linux-asp"

    # Reused committee resources

    SqlServer           = "gmfdev-hackathon-team020-sql"

    Database            = "gmfdev-hackathon-team020-sqldb"

    SearchService       = "gmfdev-hackathon-team020-foundry-search"

    # Resources created by this guide

    Factory             = "gmfdev-hackathon-team020-adf"

    WebApp              = "gmfdev-hackathon-team020-rp-web"

    ApiA                = "gmfdev-hackathon-team020-rp-api-a"

    ApiB                = "gmfdev-hackathon-team020-rp-api-b"

    ApiAppName          = "t020_RolePatrol-API-$SUFFIX"

    SpaAppName          = "t020_RolePatrol-Browser-$SUFFIX"

}

# Save names.json in project root and distribute to all team members (replaces any names.json from another subscription)

$Names | ConvertTo-Json -Depth 5 | Set-Content -Path ".\names.json" -Encoding UTF8

Write-Host "Generated names.json for the lab with Suffix: $SUFFIX" -ForegroundColor Green
```

> [!IMPORTANT]
> **`names.json` field changes vs. the original guide:** `StaticWeb` → `WebApp`, `SwaUrl` → `WebUrl`; `Collector` and `Shell` are removed; `ApiA`/`ApiB` now name Web Apps; `OwnerAGid`/`OwnerBGid` (and role/name fields) are added by Step 0.2b. The retired scripts that read the old fields live in `.\legacy\` (Section 12). The `names.json` that shipped with the sample app belongs to a different subscription and must be regenerated.

### Step 0.2b: Select the Two Demo Role Owners from the Dataset (no hard-coded people)
The portal is demonstrated by two role owners: **Owner A** (US) and **Owner B** (Canada). They are chosen from `.\datasets` — for each country, the role with the most post-transfer friction tickets (`Request_Type = Missing Role Access` and `Present_In_Role_At_Request = N`) and its `Role_Owner_GID`. The result is written into `names.json` (`OwnerAGid`, `OwnerAName`, `OwnerARoleId`, … `OwnerBGid`, …) and consumed by the directory import, SQL permissions, gateway deployment, web bundle and validation.
```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Select-RoleOwners.ps1 -DatasetDir .\datasets -NamesFile .\names.json
$names = Get-Content .\names.json | ConvertFrom-Json
"{0}: {1} {2} owns {3}" -f $names.OwnerACountry, $names.OwnerAGid, $names.OwnerAName, $names.OwnerARoleName
"{0}: {1} {2} owns {3}" -f $names.OwnerBCountry, $names.OwnerBGid, $names.OwnerBName, $names.OwnerBRoleName
# Mental model: The two demo leads are derived from the data, so the demo works with whatever dataset the committee provided.
```
> [!NOTE]
> With the current lab dataset this resolves to **Owner A = `GID0167` Kavisen Rynstead** (US, role `BR0065` Application Access Liaison, 50 friction tickets) and **Owner B = `GID0300` Nerivo Yalcrest** (Canada, role `BR0013` Governance Controls Specialist, 41 tickets). Every later step reads these values from `names.json` — if the dataset changes, re-run this step and then Steps A1, C4, D4 and D5. After Step 5.1 you can compare with the engine's own ranking and override `-CountryA/-CountryB` or edit the fields manually.



### Step 0.3: Confirm Azure Resource Providers (already registered in this lab)

```powershell
$providers = @(

    "Microsoft.Sql",

    "Microsoft.Web",

    "Microsoft.Logic",

    "Microsoft.DataFactory",

    "Microsoft.Search",

    "Microsoft.CognitiveServices"

)

foreach ($p in $providers) {

    $state = az provider show --namespace $p --query registrationState -o tsv

    if ($state -ne "Registered") { Write-Host "Registering $p (was $state)..."; az provider register --namespace $p }

    else { Write-Host "$p already Registered." -ForegroundColor Green }

}
```



### Step 0.4: Choose the Existing Resource Group & Step Up MFA for Azure Writes
**No new resource group is created.** Data Factory goes into the committee's `gmfdev-hackathon-team020-sql-rg` (next to the SQL server it connects to) and the Web Apps go into `gmfdev-hackathon-team020-linux-app-rg` (next to the App Service plan). Confirm both exist and that you can write to them:
```powershell
az group show -n $names.ResourceGroup    --query "{name:name,location:location}" -o table   # sql-rg (Data Factory)
az group show -n $names.AppResourceGroup --query "{name:name,location:location}" -o table   # linux-app-rg (Web Apps)

# Azure Resource Manager *writes* in this tenant require MFA (Conditional Access). Reads work without it. Trigger the step-up once:
az account get-access-token --resource https://management.azure.com/ --query expiresOn -o tsv
# If any later write (az webapp create, az datafactory create, ...) fails with "AADSTS50076 ... must use multi-factor authentication"
# or "InteractionRequired", re-authenticate with the claims challenge printed in the error, e.g.:
#   az logout
#   az login --tenant "1c3bd3e8-1b6d-423a-a3e4-813b1f3f6619" --scope "https://management.core.windows.net//.default" --claims-challenge "<value from the error>"
# and complete the MFA prompt in the browser. See Troubleshooting Q7.
```

> [!NOTE]
> An error like `AADSTS50076 ... you must use multi-factor authentication` is an **MFA claims challenge, not a permissions block** — the lab is not denying resource creation. Do **not** create SQL, Search or App Service resources; they already exist.



> [!IMPORTANT]

> **GATE 1 SYNC:** The Team Lead commits `names.json` to the team Git branch or shares it in the team channel. All members load this file at the start of their track:

> ```powershell
> $names = Get-Content .\names.json | ConvertFrom-Json

> ```
---

## 6. Track A: Identity, Directory & Security (Member 1)

**Owner:** Member 1 (Identity & Security Lead)  

**Duration:** ~15 minutes  

**Goal:** Provision Entra ID users and groups corresponding to `EMPLOYEE_IDENTITY.csv` and `ENTITLEMENT_CATALOG.csv`, output `identity-map.sql`, and register the API and SPA Applications under the `t020_` brand.

### Step A1: Generate Entra ID Directory from Dataset

1. Determine your verified Entra ID domain name:

   ```powershell
   $domain = (az rest --method get --uri "https://graph.microsoft.com/v1.0/domains" --query "value[?isDefault].id" -o tsv)

   Write-Host "Using default tenant domain: $domain"

   ```
2. Run `Import-DirectoryFromDataset.ps1` (it reads `OwnerAGid` / `OwnerBGid` from `names.json`; Step 0.2b must have been run):

   ```powershell
   $names = Get-Content .\names.json | ConvertFrom-Json

   $MAPDIR = ".\directory-output"

   # Allow this unsigned project script in this PowerShell process only.
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

   & .\Import-DirectoryFromDataset.ps1 `
       -VerifiedDomain $domain `
       -Prefix $names.Prefix `
       -OutputDirectory $MAPDIR `
       -DatasetDir ".\datasets"

   # 4. Set secure, documented evaluator passphrases for Owner A and Owner B
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Set-OwnerCredentials.ps1
   Write-Host "Credentials written to .\directory-output\owner-credentials.txt for login testing." -ForegroundColor Green
   ```
3. Inspect generated files in `.\directory-output\`:
   * `identity-map.csv`: Employee IDs (the two owners plus 28 other active employees) mapped to Entra Object IDs and UPNs.
   * `group-map.csv`: Entitlement groups (`ENT0001`–`ENT0016`) mapped to Entra Group Object IDs.
   * `identity-map.sql`: T-SQL `INSERT` statements for SQL tables `src.IdentityMap` and `src.GroupMap`.
   * `owner-credentials.txt`: Documented passphrases for Owner A and Owner B.
   * Note the Entra Object IDs for Owner A and Owner B:

     ```powershell
     $idMap = Import-Csv ".\directory-output\identity-map.csv"
     $OWNER_A_OBJ_ID = ($idMap | Where-Object { $_.EmployeeId -eq $names.OwnerAGid }).ObjectId
     $OWNER_B_OBJ_ID = ($idMap | Where-Object { $_.EmployeeId -eq $names.OwnerBGid }).ObjectId
     Write-Host "Owner A ($($names.OwnerAGid) $($names.OwnerAName) - US Lead) Entra Object ID: $OWNER_A_OBJ_ID" -ForegroundColor Yellow
     Write-Host "Owner B ($($names.OwnerBGid) $($names.OwnerBName) - CA Lead) Entra Object ID: $OWNER_B_OBJ_ID" -ForegroundColor Yellow
     ```
> [!NOTE]
> **Directory Scope & Live Evidence Grounding:**  
> `Import-DirectoryFromDataset.ps1` provisions the 2 Role Leads (`OwnerAGid` and `OwnerBGid`), the first 28 other active employees, and 16 Entra security groups (`ENT0001`–`ENT0016`). It then assigns group memberships via Microsoft Graph with the same rule the SQL loader uses: an employee joins the group of every entitlement that is **present in a role they currently hold** (`ROLE_ASSIGNMENTS.Assignment_Status = Active` and `ROLE_ENTITLEMENTS.Present_In_Role_Flag = Y`). The script fails loudly if either CSV is missing. This avoids Azure tenant rate-limiting while providing live, queryable Entra evidence for `Invoke-EntraCollection.ps1`. The complete 500-employee / 75-role / 600-ticket cohort is loaded into Azure SQL (`src.*`) in Track B.

> [!CAUTION]
> **Owner Credential Security & Pre-Flight Sign-In Check:**  
> `Set-OwnerCredentials.ps1` sets secure credentials for the two owners and writes them to `.\directory-output\owner-credentials.txt`. Verify interactive browser login for both leads before the live presentation. Never commit `owner-credentials.txt` to public Git repositories.

> [!WARNING]
> **Shared tenant (`gmfdev.onmicrosoft.com`):** the users, groups and apps created here are visible to every hackathon team. The `-Prefix $names.Prefix` (`t020_<suffix>`) keeps them identifiable — never use a shorter or empty prefix. Creating users needs the `User Administrator` role (Step 0.1 check). If you do not have it, ask the committee to run this step or to pre-create the users/groups, then continue with `identity-map.sql`.

> If Graph rejects a user or group creation, the importer now reports the original create error. If an existing-object lookup also fails, both errors are included; use the **Graph create error** to diagnose the cause.

> [!TIP]
> **GATE 2 HANDOFF:** Hand `identity-map.sql` to **Member 2 (Track B)** immediately. Hand `$OWNER_A_OBJ_ID` and `$OWNER_B_OBJ_ID` to **Member 3 (Track C)** and **Member 4 (Track D)** (the gateway script reads them from `identity-map.csv`).

### Step A2: Register t020 API Application in Entra ID

1. Create the API Application Registration:

   ```powershell
   $apiApp = az ad app create `
       --display-name $names.ApiAppName `
       --sign-in-audience "AzureADMyOrg" `
       --output json | ConvertFrom-Json

   $API_CLIENT_ID = $apiApp.appId

   Write-Host "API Application (Client) ID: $API_CLIENT_ID" -ForegroundColor Green

   # Create Service Principal for the API (if not already present)
   $apiSp = az ad sp list --filter "appId eq '$API_CLIENT_ID'" --query "[0].id" -o tsv
   if ($LASTEXITCODE -ne 0) { throw "Could not check for the API service principal. Resolve Azure CLI sign-in/Conditional Access, then retry." }
   if (-not $apiSp) {
       az ad sp create --id $API_CLIENT_ID | Out-Null
       if ($LASTEXITCODE -ne 0) {
           # Creation may report a duplicate if the principal already exists; verify before continuing.
           $apiSp = az ad sp show --id $API_CLIENT_ID --query id -o tsv
           if ($LASTEXITCODE -ne 0 -or -not $apiSp) { throw "Could not create or verify the API service principal." }
           Write-Host "Service Principal for API already exists ($apiSp)." -ForegroundColor Green
       } else {
           $apiSp = az ad sp show --id $API_CLIENT_ID --query id -o tsv
           if ($LASTEXITCODE -ne 0 -or -not $apiSp) { throw "Service principal creation returned success, but verification failed." }
           Write-Host "Service Principal created for API ($apiSp)." -ForegroundColor Green
       }
   } else {
       Write-Host "Service Principal for API already exists ($apiSp)." -ForegroundColor Green
   }
   ```
2. Update the API Manifest to request Access Token v2:
   *(Note: Microsoft Entra newly registered applications have an uninitialized `api` object in Microsoft Graph, so updating via `az rest` or `Deploy-Entra.ps1` avoids CLI JMESPath resolution errors)*

   ```powershell
   $appObjId = (az ad app show --id $API_CLIENT_ID --query id -o tsv)
   az rest --method PATCH --uri "https://graph.microsoft.com/v1.0/applications/$appObjId" --headers "Content-Type=application/json" --body '{\"api\":{\"requestedAccessTokenVersion\":2}}'
   ```
Verification: 
az ad app show --id $API_CLIENT_ID --query api.requestedAccessTokenVersion

3. Expose the API Scope `RolePatrol.Access`:

   ```powershell
   # Set Application ID URI
   az ad app update --id $API_CLIENT_ID --identifier-uris "api://$API_CLIENT_ID"

   # Define and expose OAuth2 scope via Microsoft Graph
   # (Note: Microsoft Graph PermissionScope schema uses 'value' for the scope name, NOT 'name')
   $scopeId = [guid]::NewGuid().ToString()
   $scopePayload = @{
       api = @{
           requestedAccessTokenVersion = 2
           oauth2PermissionScopes = @(
               @{
                   id = $scopeId
                   value = "RolePatrol.Access"
                   type = "User"
                   isEnabled = $true
                   adminConsentDisplayName = "Access Role Patrol"
                   adminConsentDescription = "Allows the Role Patrol portal to call the Role Patrol API on behalf of the signed-in role owner."
                   userConsentDisplayName = "Access Role Patrol"
                   userConsentDescription = "Allow the portal to call the Role Patrol API as you."
               }
           )
       }
   } | ConvertTo-Json -Depth 5 -Compress

   $tmpScope = Join-Path ([IO.Path]::GetTempPath()) "api-scope.json"
   [IO.File]::WriteAllText($tmpScope, $scopePayload, [Text.UTF8Encoding]::new($false))
   az rest --method PATCH --uri "https://graph.microsoft.com/v1.0/applications/$appObjId" --headers "Content-Type=application/json" --body "@$tmpScope"
   Remove-Item $tmpScope -ErrorAction SilentlyContinue

   Write-Host "RolePatrol.Access scope created ($scopeId)." -ForegroundColor Green
   ```
   **Verification:**
   ```powershell
   az ad app show --id $API_CLIENT_ID --query "api.oauth2PermissionScopes" -o json
   ```
### Step A3: Register t020 Browser SPA in Entra ID

1. Create the Single-Page Application (SPA) Registration:

   ```powershell
   $spaApp = az ad app create `
       --display-name $names.SpaAppName `
       --sign-in-audience "AzureADMyOrg" `
       --output json | ConvertFrom-Json

   $SPA_CLIENT_ID = $spaApp.appId
   Write-Host "SPA Application (Client) ID: $SPA_CLIENT_ID" -ForegroundColor Green

   # Create Service Principal for the SPA (if not already present)
   $spaSp = az ad sp list --filter "appId eq '$SPA_CLIENT_ID'" --query "[0].id" -o tsv
   if (-not $spaSp) {
       az ad sp create --id $SPA_CLIENT_ID | Out-Null
       Write-Host "Service Principal created for SPA." -ForegroundColor Green
   } else {
       Write-Host "Service Principal for SPA already exists ($spaSp)." -ForegroundColor Green
   }
   ```
2. Grant permission to call the Role Patrol API and grant Admin Consent:

   ```powershell
   # Look up scope ID if not set in current session
   if (-not $scopeId) {
       $scopeId = (az ad app show --id $API_CLIENT_ID --query "api.oauth2PermissionScopes[?value=='RolePatrol.Access'].id" -o tsv)
   }

   # Add permission for RolePatrol.Access
   az ad app permission add `
       --id $SPA_CLIENT_ID `
       --api $API_CLIENT_ID `
       --api-permissions "$scopeId=Scope"

   # Grant Admin Consent (needs Application Administrator or higher; if denied, a tenant admin must grant consent to RolePatrol.Access for this SPA)
   az ad app permission admin-consent --id $SPA_CLIENT_ID

   # 3. Save IDs into names.json for automated track handoffs
   $names | Add-Member -NotePropertyName ApiClientId -NotePropertyValue $API_CLIENT_ID -Force
   $names | Add-Member -NotePropertyName SpaClientId -NotePropertyValue $SPA_CLIENT_ID -Force
   $namesPath = if (Test-Path ".\names.json") { (Resolve-Path ".\names.json").Path } else { Join-Path $PWD "names.json" }
   [IO.File]::WriteAllText($namesPath, ($names | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
   Write-Host "names.json updated with ApiClientId ($API_CLIENT_ID) and SpaClientId ($SPA_CLIENT_ID)." -ForegroundColor Green
   ```
> [!SUCCESS]
> **Track A Complete (Gate 2 Reached):**  
> Both the API Application (`ApiClientId`) and Browser SPA Application (`SpaClientId`) are registered, scoped, and saved into `names.json`.  
> *(Note: The SPA Redirect URI will be registered in Track D as Step D3 right after the web portal Web App is provisioned—no jumping required).*  
> **➡️ Proceed immediately to Track B: Step B1 below!**
---

## 7. Track B: Data Layer & Core Governance Engine (Member 2)

**Owner:** Member 2 (Database & Engine Lead)  

**Duration:** ~20 minutes  

**Goal:** Verify the committee-provisioned Azure SQL Server and database (Entra-only auth, private endpoint), confirm private connectivity, execute schemas 01 through 07, ingest the 8 dataset CSVs using `Import-HackathonDatasets.ps1`, and (in Step C4) configure least-privilege permissions for the ADF and API Web App managed identities. **Nothing is created in this track — no firewall rules, no new server or database.**

### Step B1: Verify the Existing SQL Server & Database (Entra-Only Auth)
```powershell
$names = Get-Content .\names.json | ConvertFrom-Json

# 1. Server: expect Entra-only auth = True, publicNetworkAccess = Disabled
az sql server show -g $names.SqlResourceGroup -n $names.SqlServer --query "{name:name,pna:publicNetworkAccess,fqdn:fullyQualifiedDomainName}" -o json
az sql server ad-only-auth get -g $names.SqlResourceGroup -n $names.SqlServer --query azureADOnlyAuthentication -o tsv

# 2. Database: expect status Online, edition Standard / S0
az sql db show -g $names.SqlResourceGroup -s $names.SqlServer -n $names.Database --query "{status:status,edition:edition,slo:requestedServiceObjectiveName}" -o json

# 3. Connect with your Entra token over the private endpoint (needs the SqlServer module or System.Data.SqlClient)
$token = az account get-access-token --resource "https://database.windows.net/" --query accessToken -o tsv
Invoke-Sqlcmd -ServerInstance "$($names.SqlServer).database.windows.net" -Database $names.Database -AccessToken $token `
    -Query "SELECT SUSER_SNAME() AS Me, IS_MEMBER('db_owner') AS IsDbOwner, (SELECT COUNT(*) FROM sys.tables) AS Tables"
# Expect IsDbOwner = 1 and Tables = 0 (empty database). A non-empty database means another team member already deployed - coordinate before running 01_schema.sql.

# 4. OPTIONAL: S0 (10 DTU) is small for the assessment engine. Scale only if Step 5.1 is slow:
# az sql db update -g $names.SqlResourceGroup -s $names.SqlServer -n $names.Database --service-objective S2

# Mental model: The committee already built the server and an empty database; you only prove you can reach it privately as db_owner.
```

### Step B2: Confirm Private Connectivity (No Firewall Rules)

```powershell
# SQL public access is Disabled by lab policy: do NOT create LaptopAdminRule / AllowAllWindowsAzureIps rules.
Resolve-DnsName "$($names.SqlServer).database.windows.net" | Where-Object { $_.IPAddress } | Select-Object Name, IPAddress   # expect 10.0.58.94
Test-NetConnection "$($names.SqlServer).database.windows.net" -Port 1433                                                    # expect TcpTestSucceeded : True
# Mental model: Workstation, Data Factory (managed private endpoint) and Web Apps (VNet integration) all reach SQL privately, so no public firewall opening is needed.
```

> [!CAUTION]
> If the name resolves to a public IP or port 1433 fails, you are **not on the lab network**. Connect to the Cloud PC / VPN rather than opening the SQL firewall.

### Step B3: Deploy Schemas & Ingest Dataset CSVs

```powershell
$names = Get-Content .\names.json | ConvertFrom-Json

# Renders __OWNER_A_GID__ / __OWNER_B_GID__ / __API_A__ ... tokens from names.json, then runs the file with your Entra token
function Invoke-RpSqlFile([string]$FilePath, [hashtable]$Tokens = @{}) {
    Write-Host "Executing SQL File: $FilePath ..." -ForegroundColor Cyan
    & .\scripts\Invoke-RpSql.ps1 -InputFile $FilePath -Tokens $Tokens -NamesFile .\names.json | Out-Host
    if (-not $?) { throw "SQL file failed: $FilePath" }
}

# 1. Baseline DDL Schemas (Pure DDL, no mock seeds)
Invoke-RpSqlFile ".\sql\01_schema.sql"
# Mental model: Defines src.* staging, core.* governance ledger, and casework.* audit tables with strict constraints.

# 2. Execute ETL script to load all 8 CSVs into src.* tables (tickets file: ACCESS_REQUEST_TICKETS.csv or MOCK_ACCESS_TICKETS.csv)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Import-HackathonDatasets.ps1 `
    -SqlServer $names.SqlServer `
    -Database $names.Database `
    -DatasetDir ".\datasets"
# Mental model: Loads all 500 employees, 75 roles, 250 entitlements, and 600 tickets directly into staging tables.

# 3. Apply Entra Directory Mappings (Handed off from Track A)
Invoke-RpSqlFile ".\directory-output\identity-map.sql"
# Mental model: Binds the synthetic employees provisioned in Entra (the two role owners plus 28 others) to their live Microsoft Entra Object IDs for authenticated portal access.

# 4. Calculation Engine & Snapshot Procedures
Invoke-RpSqlFile ".\sql\02_engine.sql"
# Mental model: Installs algorithmic engine calculating friction scores, candidate entitlements, and What-If role defect simulations.

# 5. Operations & Dynamic Ingestion Validation
Invoke-RpSqlFile ".\sql\03_operations.sql"
# Mental model: Adds batch assessment orchestration, snapshot history tracking, and manual test hooks for data pipeline executions.

# 6. Status Procedures
Invoke-RpSqlFile ".\sql\04_status.sql"
# Mental model: Deploys verification procedures validating genuine row counts and zero mock data across all 8 tables.

# 7. Ticket Search Schema & Search Gateway Procedure
Invoke-RpSqlFile ".\sql\05_ticket_search.sql"
# Mental model: Exposes enriched ticket search views and context-matching stored procedures queried by Azure AI Search.

# 8. Portal API + Application Master (07_portal_api.sql, src.Application from APPLICATION_MASTER.csv, ticket context realignment, 08_portfolio_access.sql)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Apply-PortalApi.ps1 -SkipAssess
# Mental model: Deploys the portal API procedures (api.usp_Catalog, api.usp_Gateway) and loads the 40 applications the catalog needs; the assessment itself is published later (Step 5.1).

Write-Host "All baseline database schemas, datasets, and procedures installed successfully." -ForegroundColor Green
# Mental model: Concludes foundational database deployment with all 8 CSV datasets loaded and ready for pipeline processing.
```

> [!NOTE]
> `Apply-PortalApi.ps1 -SkipAssess` is required: `api.usp_Catalog` reads `src.Application`, which only this script loads. `sql\06_permissions.sql` is run later in Step C4 once the managed identities exist.
---

## 8. Track C: Orchestration & Compute Deployment

**Goal:** Provision Azure Data Factory (`gmfdev-hackathon-team020-adf`) with a managed virtual network and managed private endpoint to the private SQL server, deploy the assessment pipeline anchored to the dataset timeline (`2026-10-01`), create the API gateway Web Apps (private, on the existing Linux plan), and bind Managed Identity users in Azure SQL.

### Step C1: Deploy Azure Data Factory (Managed VNet + Private Endpoint to SQL)
```powershell
$names = Get-Content .\names.json | ConvertFrom-Json

# 1. Create Azure Data Factory (system-assigned identity is created automatically)
az datafactory create `
    --resource-group $names.ResourceGroup `
    --factory-name $names.Factory `
    --location $names.Location
# Mental model: Provisions Data Factory compute instance hosting scheduled assessment pipelines and SQL data flows.

# 1b. Managed virtual network, Managed VNet integration runtime, and managed private endpoint to the SQL server
$sqlId   = az sql server show -g $names.SqlResourceGroup -n $names.SqlServer --query id -o tsv
$adfBase = "https://management.azure.com/subscriptions/$($names.SubscriptionId)/resourceGroups/$($names.ResourceGroup)/providers/Microsoft.DataFactory/factories/$($names.Factory)"

function Invoke-AdfPut([string]$Path, $Body) {
    $tmp = [IO.Path]::GetTempFileName()
    [IO.File]::WriteAllText($tmp, ($Body | ConvertTo-Json -Depth 10 -Compress), [Text.UTF8Encoding]::new($false))
    az rest --method PUT --uri "${adfBase}/${Path}?api-version=2018-06-01" --headers "Content-Type=application/json" --body "@$tmp" | Out-Null
    Remove-Item $tmp -ErrorAction SilentlyContinue
}

Invoke-AdfPut "managedVirtualNetworks/default" @{ properties = @{} }
Invoke-AdfPut "integrationRuntimes/ManagedVnetIR" @{ properties = @{
    type = "Managed"
    typeProperties = @{ computeProperties = @{ location = "AutoResolve" } }
    managedVirtualNetwork = @{ type = "ManagedVirtualNetworkReference"; referenceName = "default" } } }
Invoke-AdfPut "managedVirtualNetworks/default/managedPrivateEndpoints/sql-pe" @{ properties = @{ privateLinkResourceId = $sqlId; groupId = "sqlServer" } }

# 1c. Approve the pending private endpoint connection on the SQL server (requires Owner)
Start-Sleep -Seconds 30
$pending = az network private-endpoint-connection list --id $sqlId --query "[?properties.privateLinkServiceConnectionState.status=='Pending'].id" -o tsv
foreach ($c in $pending) { az network private-endpoint-connection approve --id $c --description "Role Patrol ADF managed private endpoint" }
# Mental model: SQL public access is disabled, so ADF reaches SQL through its own managed private endpoint that the SQL owner approves.

# 2. Deploy Azure SQL Linked Service (ADF System-Assigned Managed Identity, running on the Managed VNet IR)
$lsJson = (Get-Content ".\templates\adf-sql-linkedservice.json" -Raw).Replace("__SQL_SERVER__", "$($names.SqlServer).database.windows.net").Replace("__DATABASE__", $names.Database)
$lsObj  = $lsJson | ConvertFrom-Json
$lsObj | Add-Member -NotePropertyName connectVia -NotePropertyValue ([pscustomobject]@{ referenceName = "ManagedVnetIR"; type = "IntegrationRuntimeReference" }) -Force
$lsFile = ".\adf-ls-temp.json"
Set-Content -Path $lsFile -Value ($lsObj | ConvertTo-Json -Depth 10)
az datafactory linked-service create `
    --resource-group $names.ResourceGroup `
    --factory-name $names.Factory `
    --linked-service-name "RolePatrolSql" `
    --properties "@$lsFile"
Remove-Item $lsFile
# Mental model: Configures passwordless SQL connection authenticated directly via Data Factory's System-Assigned Managed Identity over the private endpoint.

# 3. Deploy Assessment Pipeline anchored to 2026-10-01
$pipeJson = Get-Content ".\templates\adf-assessment-pipeline.json" -Raw
$pipeFile = ".\adf-pipe-temp.json"
Set-Content -Path $pipeFile -Value $pipeJson
az datafactory pipeline create `
    --resource-group $names.ResourceGroup `
    --factory-name $names.Factory `
    --pipeline-name "RolePatrolAssessment" `
    --pipeline "@$pipeFile"
Remove-Item $pipeFile

Write-Host "Data Factory and Pipeline deployed with @BusinessAsOf 2026-10-01." -ForegroundColor Green
# Mental model: Deploys 5-pillar assessment pipeline processing historical access requests, movements, and entitlements.
```

> [!NOTE]
> **ADF fallback:** if ADF is disallowed by policy, its managed private endpoint stays `Pending`/`Rejected`, or the pipeline cannot connect, run the procedures directly from the lab workstation as `db_owner` in a single SQL batch:
> ```sql
> EXEC core.usp_Ingest;
> DECLARE @RunId uniqueidentifier = NEWID();
> EXEC core.usp_Assess @RunId = @RunId, @BusinessAsOf = '2026-10-01T12:00:00';
> ```
> This publishes the assessment without an ADF pipeline. The ADF-dependent portion of Step C4 must be skipped or adapted if ADF was not created. See Troubleshooting Q8.

### Step C2: Create the Web App & API Gateway Apps on the Existing Linux Plan
Create three Linux Node Web Apps on the committee plan `gmfdev-hackathon-team020-linux-asp`: the portal (`WebApp`) and two owner-scoped API gateways (`ApiA`, `ApiB`). The subscription policy requires VNet integration to be present in the initial app resource request, so deploy the apps through ARM with `properties.virtualNetworkSubnetId`; do not create them first and attach VNet integration afterward.
```powershell
$names = Get-Content .\names.json | ConvertFrom-Json

$planJson = az appservice plan show -g $names.AppResourceGroup -n $names.AppServicePlan `
    --query "{id:id,kind:kind,reserved:reserved}" -o json
if ($LASTEXITCODE -ne 0) { throw "Could not read the App Service plan." }
$plan = $planJson | ConvertFrom-Json
if ($plan.reserved -ne $true -and $plan.kind -notmatch "linux") {
    throw "The existing App Service plan is not confirmed as Linux (kind=$($plan.kind), reserved=$($plan.reserved)). Check with the support team before deploying."
}
$planId = $plan.id

$vnetId = az network vnet show -g $names.NetworkResourceGroup -n $names.VNet --query id -o tsv
if ($LASTEXITCODE -ne 0 -or -not $vnetId) { throw "Could not find the configured VNet." }
$appSubnetId = "$vnetId/subnets/$($names.AppSubnet)"

$subnetJson = az network vnet subnet show --ids $appSubnetId `
    --query "{delegation:delegations[0].serviceName,links:serviceAssociationLinks[].linkedResourceType}" -o json
if ($LASTEXITCODE -ne 0) { throw "Could not read the App Service integration subnet." }
$subnet = $subnetJson | ConvertFrom-Json
if ($subnet.delegation -ne "Microsoft.Web/serverFarms") {
    throw "The integration subnet must be delegated to Microsoft.Web/serverFarms."
}

$apps = @($names.WebApp, $names.ApiA, $names.ApiB)
$resources = foreach ($app in $apps) {
    @{
        type       = "Microsoft.Web/sites"
        apiVersion = "2022-03-01"
        name       = $app
        location   = $names.Location
        kind       = "app,linux"
        identity   = @{ type = "SystemAssigned" }
        properties = @{
            serverFarmId          = $planId
            httpsOnly             = $true
            virtualNetworkSubnetId = $appSubnetId
            siteConfig            = @{ linuxFxVersion = "NODE|24-lts" }
        }
    }
}

$template = [ordered]@{
    '$schema'      = "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"
    contentVersion = "1.0.0.0"
    resources      = @($resources)
}
$templatePath = Join-Path $env:TEMP "role-patrol-apps-vnet.json"
try {
    $template | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $templatePath -Encoding utf8
    az deployment group create -g $names.AppResourceGroup `
        --name "role-patrol-apps-vnet" --template-file $templatePath `
        --only-show-errors -o none
    if ($LASTEXITCODE -ne 0) { throw "ARM deployment failed. Check the deployment details before retrying." }
}
finally {
    if (Test-Path -LiteralPath $templatePath) { Remove-Item -LiteralPath $templatePath -Force }
}

# Verify each app was created with its managed identity and VNet integration.
foreach ($app in $apps) {
    $appId = az webapp show -g $names.AppResourceGroup -n $app --query id -o tsv
    if ($LASTEXITCODE -ne 0 -or -not $appId) { throw "Web App was not created: $app" }
    az resource show --ids $appId --api-version "2022-03-01" `
        --query "{name:name,subnet:properties.virtualNetworkSubnetId,identity:identity.type,httpsOnly:properties.httpsOnly,linuxFxVersion:properties.siteConfig.linuxFxVersion}" -o table
    if ($LASTEXITCODE -ne 0) { throw "Could not verify Web App configuration: $app" }
}

# Portal serves the pre-built SPA bundle as static files (SPA fallback enabled)
az webapp config set -g $names.AppResourceGroup -n $names.WebApp --startup-file "pm2 serve /home/site/wwwroot --no-daemon --spa" | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Could not configure the portal startup command." }
az webapp config appsettings set -g $names.AppResourceGroup -n $names.WebApp --settings SCM_DO_BUILD_DURING_DEPLOYMENT=false | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Could not configure portal app settings." }

Write-Host "3 Web Apps created with Managed Identities and VNet integration set at creation." -ForegroundColor Green
# Mental model: Serverless-style hosting on the committee plan; managed identities replace passwords, VNet integration reaches private SQL/Search.
```
> [!NOTE]
> `NODE|24-lts` must be available in the region/plan; it was listed as available in the hackathon subscription. If the global app names are already taken, update the three names in `names.json` before deploying. The VNet integration subnet must be delegated to `Microsoft.Web/serverFarms` and must have capacity available.
>
> **Workflow Functionality Scope:**
> * **`ApiA` & `ApiB`**: Become production OAuth 2.0 API gateways in Step D4 (`Deploy-AppServiceGateway.ps1`), enforcing tenant tokens, validating caller identity (Owner A / Owner B object IDs), and invoking `api.usp_Gateway`. They replace the Consumption Logic Apps of the original design (Section 1A, D2).
> * **Collector & Shell**: Not deployed. Live directory collection into SQL is driven by `.\scripts\Invoke-EntraCollection.ps1` run from the lab workstation (Step 5.1).
> * **Name collisions:** `*.azurewebsites.net` names are global. If `az webapp create` reports the name is taken, append `-<suffix>` to the three names in `names.json` and re-run.

### Step C3: Private Endpoints for the Web Apps (Inbound Access)
The committee already linked the `privatelink.azurewebsites.net` Private DNS zone to the VNet. Add one private endpoint per app and register it in that zone (same `default` DNS zone group pattern the committee used for SQL/Search):
```powershell
$peSubnetId = "$vnetId/subnets/$($names.PeSubnet)"
$zoneId     = az network private-dns zone show -g $names.NetworkResourceGroup -n privatelink.azurewebsites.net --query id -o tsv

foreach ($app in @($names.WebApp, $names.ApiA, $names.ApiB)) {
    $appId = az webapp show -g $names.AppResourceGroup -n $app --query id -o tsv
    az network private-endpoint create -g $names.AppResourceGroup -n "$app-pe" --location $names.Location `
        --subnet $peSubnetId --private-connection-resource-id $appId --group-id sites --connection-name "$app-conn" | Out-Null
    az network private-endpoint dns-zone-group create -g $names.AppResourceGroup --endpoint-name "$app-pe" -n default `
        --private-dns-zone $zoneId --zone-name azurewebsites | Out-Null

    # Recommended: close the public endpoint once the private endpoint exists (lab is private-only)
    az resource update -g $names.AppResourceGroup -n $app --resource-type "Microsoft.Web/sites" --set properties.publicNetworkAccess=Disabled | Out-Null

    Resolve-DnsName "$app.azurewebsites.net" | Where-Object { $_.IPAddress } | Select-Object Name, IPAddress   # expect 10.0.58.x
}
# Mental model: The apps are reachable only from the lab network - the same boundary as SQL and Search.
```
> [!CAUTION]
> With public access disabled the demo must be given from a lab-network machine (Cloud PC / VPN). Zip deployment (Step D6) and the Kudu/SCM site also go through the private endpoint, so deploy from the lab network too.

### Step C4: Provision SQL Managed Identity Users & Evaluator Permissions
The API Web Apps have System-Assigned Managed Identities. Execute this script to map their binary SIDs in Azure SQL (`sql\06_permissions.sql`), grant least-privilege EXECUTE permissions, seed the two role owners (**Owner A** = `names.OwnerAGid`, **Owner B** = `names.OwnerBGid`) and apply portfolio access / evaluator authority (`08`, `09`). ADF is blocked by subscription policy, so its identity lookup and SQL grants are commented out for now; retain those comments to resume the ADF setup if it is approved later. The owner GIDs are substituted into the SQL files from `names.json` — nothing is hard-coded. Run it from the lab network as a `db_owner` (your owner-group identity); no Directory Readers role is needed because the users are created `WITH SID ... TYPE=E`:
```powershell
$names = Get-Content .\names.json | ConvertFrom-Json
foreach ($k in 'OwnerAGid','OwnerBGid') { if (-not $names.$k) { throw "names.json has no $k - run Step 0.2b." } }

function Invoke-RpSqlFile([string]$FilePath, [hashtable]$Tokens = @{}) {
    Write-Host "Executing SQL script: $FilePath ..." -ForegroundColor Cyan
    & .\scripts\Invoke-RpSql.ps1 -InputFile $FilePath -Tokens $Tokens -NamesFile .\names.json | Out-Host
    if (-not $?) { throw "SQL file failed: $FilePath" }
    Write-Host "SUCCESS: $FilePath applied." -ForegroundColor Green
}

function Get-SidHex([string]$appId) {
    $guid = [guid]$appId
    '0x' + (($guid.ToByteArray() | ForEach-Object { $_.ToString('X2') }) -join '')
}

# Retrieve Application (Client) IDs of the API Managed Identities:
# ADF is unavailable under current policy. Uncomment this lookup if ADF is approved and deployed:
<#
$adfSpId = (az ad sp show --id (az datafactory show -g $names.ResourceGroup -n $names.Factory --query identity.principalId -o tsv) --query appId -o tsv)
#>
$apiASpId = (az ad sp show --id (az webapp identity show -g $names.AppResourceGroup -n $names.ApiA --query principalId -o tsv) --query appId -o tsv)
$apiBSpId = (az ad sp show --id (az webapp identity show -g $names.AppResourceGroup -n $names.ApiB --query principalId -o tsv) --query appId -o tsv)

# Verify both API Managed Identity Application IDs are resolved
$identityTable = @(
    [PSCustomObject]@{ Resource = "API A ($($names.ApiA))";           AppId = $apiASpId },
    [PSCustomObject]@{ Resource = "API B ($($names.ApiB))";           AppId = $apiBSpId }
)
# To resume ADF, add this row after uncommenting the ADF lookup:
# [PSCustomObject]@{ Resource = "Data Factory ($($names.Factory))"; AppId = $adfSpId },
$identityTable | Format-Table -AutoSize

foreach ($id in $identityTable) {
    if (-not $id.AppId) { throw "Missing Application ID for $($id.Resource). Verify resource provisioning." }
}
Write-Host "Both API Managed Identity Application IDs verified." -ForegroundColor Green
# Mental model: Confirms valid directory client IDs retrieved for each managed identity before mapping into SQL.

# Managed-identity users, EXECUTE grants, principal map and owner permissions (tokens __API_A__, __API_B__,
# __OWNER_A_GID__, __OWNER_B_GID__ come from names.json; the API SIDs are passed in)
Invoke-RpSqlFile ".\sql\06_permissions.sql" @{
    '__API_A_SID__' = (Get-SidHex $apiASpId)
    '__API_B_SID__' = (Get-SidHex $apiBSpId)
    # To resume ADF, uncomment after ADF is deployed and its lookup above is enabled:
    # '__ADF_SID__' = (Get-SidHex $adfSpId)
}

# Apply Portfolio Cross-Role Read Access and Evaluator Permissions (Final Authority)
Write-Host "Applying portfolio access and evaluator action authority..." -ForegroundColor Cyan
Invoke-RpSqlFile ".\sql\08_portfolio_access.sql"
Invoke-RpSqlFile ".\sql\09_enable_evaluator_actions.sql"

# Check resulting permissions for both owners before portal deployment
Write-Host "Verifying permissions for Owner A ($($names.OwnerAGid)) and Owner B ($($names.OwnerBGid))..." -ForegroundColor Cyan
& .\scripts\Invoke-RpSql.ps1 -NamesFile .\names.json -Query "SELECT EmployeeId, COUNT(*) AS TotalRoles, SUM(CONVERT(int, CanDecide)) AS DecidableRoles FROM core.Permission GROUP BY EmployeeId;" | Format-Table -AutoSize

Write-Host "API Managed Identity SQL users, principal mappings, and verified evaluator permissions configured successfully." -ForegroundColor Green
# Mental model: Binds Managed Identities to database roles and provisions role owners with certification authority.
```
> [!NOTE]
> `06_permissions.sql` stops with an error if either owner owns no role in `src.Role` (for example after the dataset changed): re-run Step 0.2b and reload. Because `Invoke-RpSql.ps1` fails on any unresolved `__TOKEN__`, a missing value can never silently produce an empty permission set.

#### Single-account synthetic demo (no bulk A1 import)
The normal two-owner deployment requires both owner object IDs. For an approved single-owner demo, use your own signed-in Entra account for Owner A only. This maps your account to the synthetic `names.OwnerAGid` and uses the evaluator permissions configured above across the synthetic portfolio; keep the service private and do not use production data. This does not provision synthetic directory users or provide live membership evidence.

Run the following lines as PowerShell commands. Do **not** include the `PS>` prompt or any leading `>` characters:
```powershell
$names = Get-Content .\names.json -Raw | ConvertFrom-Json
$identityJson = az ad signed-in-user show --query "{ObjectId:id,UPN:userPrincipalName}" -o json
if ($LASTEXITCODE -ne 0 -or -not $identityJson) { throw "Could not read the signed-in Entra account." }
$demoIdentity = $identityJson | ConvertFrom-Json
$demoIdentity | Format-List
if ((Read-Host "Confirm this is your approved demo account by typing YES") -cne "YES") { throw "Demo identity not confirmed." }
if (Test-Path .\directory-output\identity-map.csv) { throw "identity-map.csv already exists; inspect it before replacing it." }
New-Item -ItemType Directory -Path .\directory-output -Force | Out-Null
[pscustomobject]@{
    EmployeeId = $names.OwnerAGid
    ObjectId   = $demoIdentity.ObjectId
    UPN        = $demoIdentity.UPN
} | Export-Csv -LiteralPath .\directory-output\identity-map.csv -NoTypeInformation -Encoding utf8
Import-Csv .\directory-output\identity-map.csv | Format-Table -AutoSize
```
This local mapping is ignored by Git. Do not map the same account to Owner B. For the single-owner deployment, keep the Owner B gateway unused.
---

## 9. Track D: Search & Web Portal Deployment

**Goal:** Use the existing Azure AI Search service (`gmfdev-hackathon-team020-foundry-search`) for ticket retrieval, resolve the private web portal URL, configure OAuth API gateways, build production bundles, and publish the portal.

### Step D1: Create the `ticket-text` Index on the Existing Azure AI Search Service
```powershell
$names = Get-Content .\names.json | ConvertFrom-Json

# 1. Verify the committee search service (Basic, public access Disabled) and list existing indexes
az search service show -g $names.SearchResourceGroup -n $names.SearchService --query "{sku:sku.name,pna:publicNetworkAccess,auth:authOptions}" -o json
$searchToken = az account get-access-token --resource "https://search.azure.com" --query accessToken -o tsv
(Invoke-RestMethod -Uri "https://$($names.SearchService).search.windows.net/indexes?api-version=2024-07-01&`$select=name" -Headers @{ Authorization = "Bearer $searchToken" }).value
# The service is shared with Foundry. The original setup began with an empty service; the live lab now has ticket-text (600 documents). Preserve it and never delete or alter unrelated indexes.
# Mental model: Reuses the committee's private search service instead of provisioning a new one.

# 2. Run automated search deployment script (Index definition & Direct Semantically Enriched CSV Ingestion)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\search\Deploy-Search.ps1 -NamesFile "..\names.json"
# Mental model: Creates ticket-text index and pushes 600 enriched access request tickets with business metadata.
# (Deploy-Search.ps1 reads $names.SearchResourceGroup / $names.SqlResourceGroup; it does not touch the shared service's identity unless -UseSqlIndexer is passed.)

# 3. Verify ticket-text index contains all 600 enriched access request tickets
$docCount = (Invoke-RestMethod -Uri "https://$($names.SearchService).search.windows.net/indexes/ticket-text/docs/`$count?api-version=2024-07-01" -Headers @{ Authorization = "Bearer $searchToken" })
Write-Host "Azure AI Search index 'ticket-text' verified with $docCount documents." -ForegroundColor Green
# Mental model: Confirms ticket search index is populated and ready to serve real-time semantic queries.

# 4. Let the two API gateway managed identities query the index (Search Index Data Reader)
$searchId = az search service show -g $names.SearchResourceGroup -n $names.SearchService --query id -o tsv
foreach ($app in @($names.ApiA, $names.ApiB)) {
    $principalId = az webapp identity show -g $names.AppResourceGroup -n $app --query principalId -o tsv
    az role assignment create --assignee-object-id $principalId --assignee-principal-type ServicePrincipal `
        --role "Search Index Data Reader" --scope $searchId | Out-Null
}
# Mental model: Gateways call Search with their managed identity (no API keys) over the private endpoint.
```
> [!NOTE]
> **Deterministic Search Ingestion:** `Deploy-Search.ps1` deploys the index schema and directly pushes all 600 access request tickets joined with business role titles, application names, and entitlement access levels into `ticket-text`. This guarantees deterministic semantic search availability and eliminates SQL indexer identity permission latency during the hackathon. The service allows both Entra and API-key auth; the verification above uses your Entra token (owner group holds *Search Index Data Contributor*).
>

### Step D2: Resolve the Web Portal URL (replaces Static Web Apps)
```powershell
$names = Get-Content .\names.json | ConvertFrom-Json

# The portal Web App was created in Step C2; resolve its hostname (no Static Web App is used in this lab)
$hostName = (az webapp show -n $names.WebApp -g $names.AppResourceGroup --query defaultHostName -o tsv)
$WEB_URL  = "https://$hostName"

# Persist WebUrl into names.json for automated handoffs (Gateways, CORS & Entra Redirect URIs)
$names | Add-Member -NotePropertyName WebUrl -NotePropertyValue $WEB_URL -Force
$namesPath = if (Test-Path ".\names.json") { (Resolve-Path ".\names.json").Path } else { Join-Path $PWD "names.json" }
[IO.File]::WriteAllText($namesPath, ($names | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))

Write-Host "Web Portal Hostname: $WEB_URL (saved to names.json)" -ForegroundColor Green
# Mental model: Resolves and registers the private hosting URL into the configuration registry for gateway CORS and redirect URIs.
```

### Step D3: Register Web App Redirect URI in Entra ID
Now that the portal Web App URL (`$WEB_URL`) is known, register the MSAL redirect URIs on your Browser SPA application (`$names.SpaClientId`). Entra only needs the URI string — it does not call the app, so a private-only hostname works:
```powershell
$redirectUri = "$WEB_URL/bridge.html"

# Azure CLI does not support a dedicated --spa-redirect-uris flag; configure spa.redirectUris via Microsoft Graph API:
$spaAppObjId = (az ad app show --id $names.SpaClientId --query id -o tsv)
$tmpSpa = [IO.Path]::GetTempFileName()
$spaPayload = @{
    spa = @{
        redirectUris = @($redirectUri, "$WEB_URL/")
    }
} | ConvertTo-Json -Compress

[IO.File]::WriteAllText($tmpSpa, $spaPayload, [Text.UTF8Encoding]::new($false))
az rest --method PATCH --uri "https://graph.microsoft.com/v1.0/applications/$spaAppObjId" --headers "Content-Type=application/json" --body "@$tmpSpa"
Remove-Item $tmpSpa -ErrorAction SilentlyContinue

Write-Host "Configured SPA Redirect URIs in Entra ID: $redirectUri and $WEB_URL/" -ForegroundColor Green
# Mental model: Authorizes the Web App domain to receive Entra ID OAuth tokens via MSAL browser redirects.
```

### Step D4: Deploy API Gateways on the Web Apps & Secure Them
Now that the Web App URL, AI Search service, and Entra client IDs are registered, execute `Deploy-AppServiceGateway.ps1` to configure the OAuth-protected API gateways. Use the default command for both approved owners, or `-SingleOwnerDemo` to deploy only `ApiA` for the approved Owner A demo identity created in Step C4. Authentication and owner-ID validation remain enabled in either mode. The gateway source is in `.\gateway\` (`server.js`, Node 20, dependency: `tedious`); its Entra-token policy has offline unit tests (`cd gateway; node --test`).
```powershell
# Standard two-owner deployment:
# Sets app settings (tenant, API client ID, SPA client ID, owner object ID from identity-map.csv, SQL server/DB, search service,
# allowed web origin, pre-fetched Entra signing keys), zip-deploys .\gateway to both Web Apps, checks /healthz through the private
# endpoint, and writes web\config.json (apiByObjectId, clientId, apiClientId, redirectUri) plus ApiAUrl/ApiBUrl into names.json:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Deploy-AppServiceGateway.ps1

# For this single-account synthetic demo instead, deploy only Owner A's gateway:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Deploy-AppServiceGateway.ps1 -SingleOwnerDemo
# Mental model: Configures OAuth-secured API gateways with caller token validation and updates web client configuration.
```
> [!NOTE]
> In `-SingleOwnerDemo` mode, only your account's object ID is routed to ApiA, whose SQL principal is mapped to the synthetic Owner A GID. ApiB is not deployed/configured by this command. Do not use this mode with production data or represent the single account as both owners.
>
> D4 writes `web\config.json` locally; it does not publish the portal. Complete D5 and D6 so the built portal embeds this owner-to-ApiA mapping and the updated bundle is deployed.
**Gateway contract** (same behaviour as the original Logic App workflow, so the portal code only needs the URLs in `config.json`):

| Aspect | Implementation in `gateway\server.js` |
|---|---|
| Endpoint | `POST https://<api-app>.azurewebsites.net/api/gateway` (JSON body, same `op` / payload fields the portal already sends); `GET /healthz` is unauthenticated |
| Caller authentication | Validates the Entra v2 bearer token: RS256 signature against the tenant signing keys, `iss = https://login.microsoftonline.com/<tenant>/v2.0`, `aud = <ApiClientId>`, `tid = <tenant>`, `azp = <SpaClientId>`, `scp` contains `RolePatrol.Access`, `exp`/`nbf`, and `oid` = this gateway's owner (Owner A's Entra object ID for API-A, Owner B's for API-B). Everything else gets 401/403. |
| SQL access | Managed identity token for `https://database.windows.net/` → `EXEC api.usp_Gateway @Payload = <request JSON>` over the private endpoint; the first row's `HttpStatus` / `ResponseJson` become the HTTP status and body. |
| Ticket search (`op = ticketSearch`, `searchAction != refresh`) | Managed identity token for `https://search.azure.com/` → `POST /indexes/ticket-text/docs/search` (`queryType=semantic`, `semanticConfiguration=ticket-semantic`, `searchFields=ticketText`, `select=ticketId`, `top=20`); on failure a lexical (`simple`) retry; then `api.usp_Gateway` with `searchResponse` and `searchMode` (`Semantic` / `Lexical`); HTTP 503 if both searches fail. |
| CORS | Allows only `WEB_ORIGIN` (= `names.WebUrl`); answers the `OPTIONS` preflight. |
| `web/config.json` | `apiByObjectId` maps each owner's Entra object ID to its gateway URL; `redirectUri` = `$WEB_URL/bridge.html`. |
> [!NOTE]
> `Deploy-AppServiceGateway.ps1` replaces the retired `Deploy-LogicAppGateway.ps1` (Consumption Logic Apps cannot reach the private-only SQL server and Search service). The original workflow in `templates\logicapp-api-workflow.json` is kept only as the behavioural reference.
>
> **Dependencies:** if `npm ci` works on your machine, run it once in `.\gateway` so `node_modules` (tedious) is bundled into the zip. Otherwise the script sets `SCM_DO_BUILD_DURING_DEPLOYMENT=true` and the App Service installs it — that needs outbound access to the npm registry from the Web App; if it fails, install `tedious` on any machine with npm access and copy `gateway\node_modules` over. The token policy is unit-tested offline; the SQL/Search calls can only be exercised in the lab (use the Step 5.2 validation and the portal).

### Step D5: Build Web Artifacts with Dataset Owners
Everything demo-specific in the portal (baseline catalog, owner sign-in hints, Role Differentiator presets, quick searches) is **generated from the dataset and `names.json`** — nothing from the original sample dataset remains. The committed `web\dist\index.html` of the sample app was removed because it embedded another tenant's IDs and another dataset's roles. Build the portal in three PowerShell steps (no npm required):
```powershell
# 1. Regenerate web\catalog-data.js (40 apps, 250 entitlements, 75 roles) and web\demo-config.json from .\datasets + names.json
#    (run after Step C4; in single-owner demo mode the local mapping provides the Owner A sign-in hint)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\web\Build-Catalog.ps1 -DatasetDir .\datasets -NamesFile .\names.json

# 2. Build dist\app.js = prebuilt MSAL (web\vendor\msal-bundle.js) + catalog-data.js + app.js - no npm / esbuild needed
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\web\Build-App.ps1

# 3. Compile production HTML (inlines CSS, the app bundle, web\config.json written by Step D4, and web\demo-config.json)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\web\Build-Html.ps1 -ConfigFile .\web\config.json

Write-Host "Web bundle built in web\dist (index.html, bridge.html, app.js, bridge.js)." -ForegroundColor Green
# Mental model: Compiles the frontend bundle with embedded theme tokens, SVGs, MSAL configuration and dataset-derived demo settings.
```

> [!IMPORTANT]
> **npm is optional.** `registry.npmjs.org` is blocked from the lab network (TLS interception), so the build above replaces `npm run build:app` with `Build-App.ps1`, which splices the already-built MSAL code (`web\vendor\msal-bundle.js`, @azure/msal-browser 5.25.0) in front of the unminified application code. If you do have npm access you can still run `npm ci; npm run build:app; npm run build:bridge` in `.\web` (run `Build-Catalog.ps1` first), then `Build-Html.ps1`.
> 1. **Always run `Build-Catalog.ps1` and `Build-Html.ps1`** — the portal must be built with this lab's tenant/client IDs and dataset.
> 2. **Option B (Build on another machine):** GitHub Actions / SWA CI-CD is **not applicable** (no Static Web App, private-only hosting). Build on any machine and copy `web\dist` to the lab workstation before Step D6.
> 3. **Option C (Microsoft CDN Script Tags):** If editing frontend code without a bundler, reference the official Microsoft MSAL CDN in `index.html` (`https://alcdn.msauth.net/browser/2.38.0/js/msal-browser.min.js`) for pure vanilla JS with zero dependencies.
> 4. **Option D (Azure Storage Static Website):** Not used in this lab — storage accounts are private-endpoint only and `$web` would not be reachable. Deploy to the Web App instead.

> [!TIP]
> **Streamlined Executive Simple View UX:** The portfolio table features a clean, high-signal 4-column layout (`Rank`, `Role & Department`, `Impact`, `Action`). The previous `Mover Impact` column is renamed to **`Impact`** and the redundant `Engine Status` column is removed for maximum executive focus.
>
> **5 Grounded Pillars of Proof in Evidence Drawer:** The Evidence Drawer presents all 5 pillars of proof with generous vertical spacing (16px gap) and noise-reduced cards:
> 1. *Pillar 1 · Root Cause Role Defect*: Explicit missing entitlement and required access level.
> 2. *Pillar 2 · Target Application Scope*: Target SaaS apps, platforms, and operational divisions.
> 3. *Pillar 3 · Verified Employee Complaints*: Verified post-transfer complaint tickets with direct quotes.
> 4. *Pillar 4 · Peer Group Prevalence Benchmark*: Empirical peer adoption benchmarks and live Entra ID group membership.
> 5. *Pillar 5 · Upcoming Mover Projections*: Scheduled upcoming transfers into the role to prevent day-one outages.
>
> **Multi-Insight Role Differentiator:** The Role Differentiator tool provides 3 intuitive tabs:
> 1. *🔑 Entitlements*: Side-by-side entitlement cards with risk badges, app tags, AD group tags, and direct `+ Req` ServiceNow buttons.
> 2. *👥 AD Security Groups*: Direct Active Directory / Microsoft Entra Security Groups (`SG-APP...-ENT...`) synchronized through identity access packages.
> 3. *💻 Application Access*: Comparative software platforms grid detailing applications in Role B, applications in Role A, and shared systems.

### Step D5.1: Reset Role Owner Sign-In Credentials (Local)
For the normal two-owner setup, reset the passwords for the two role owner demo accounts in Entra ID and save them to `directory-output\owner-credentials.txt`:
```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Set-OwnerCredentials.ps1
# Mental model: Generates fresh credentials for the two owners (names.OwnerAName / names.OwnerBName) for live role certification sign-in.
```
> [!NOTE]
> **Single-owner demo:** Skip this step. Sign in with your existing approved account; do not reset or store its password.

### Step D6: Deploy the Portal to the Web App
```powershell
# Zips web\dist\index.html + bridge.html and deploys them to the portal Web App (run from the lab network; the SCM site is private).
# The script refuses to deploy a build that does not contain this lab's tenant and SPA client IDs.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Deploy-WebApp.ps1

Write-Host "Portal successfully published to $($names.WebUrl)" -ForegroundColor Green
# Mental model: Deploys compiled web bundle to the private portal Web App on the committee App Service plan.
```
> [!NOTE]
> **Deployment Endpoint:**
> * **Portal Web URL:** `$names.WebUrl` (e.g. `https://gmfdev-hackathon-team020-rp-web.azurewebsites.net`, resolves to a private `10.0.58.x` address)
> * **OAuth MSAL Redirect Bridge:** `$names.WebUrl/bridge.html`
> * **Azure Resource:** `$names.WebApp` in Resource Group `$names.AppResourceGroup`
>
> `Deploy-Swa.ps1` is no longer used. Open the portal from a lab-network machine (Cloud PC / VPN).

### Step D7: Implement Role X-Ray (Read-Only Role Composition)

**Goal:** Let an authorized role owner inspect the composition of a business role as:

```text
Business Role → Present Entitlements → Associated Application
```

Role X-Ray is an inventory view, not an evidence or remediation view. It must not display complaint tickets, employee evidence, what-if results, governance cases, or write actions. The current synthetic dataset maps each entitlement to one application; show the application next to its entitlement. Do not imply that one entitlement maps to multiple applications.

#### D7.1 Confirm the existing SQL data; do not reload it

The current portal catalog already returns roles, present entitlement IDs, entitlement display names, and application names/categories. The dataset importer loads only `Present_In_Role_Flag = 'Y'` rows into `src.RoleEntitlement`. **Do not rerun `Import-HackathonDatasets.ps1` to add this UI feature:** it deletes and reloads source tables.

From the repository root, run this read-only verification:

```powershell
$query = @'
WITH RoleSizes AS (
    SELECT r.RoleId, COUNT(re.EntitlementId) AS PresentEntitlements
    FROM src.Role r
    LEFT JOIN src.RoleVersion rv ON rv.RoleId = r.RoleId AND rv.ValidTo IS NULL
    LEFT JOIN src.RoleEntitlement re ON re.VersionId = rv.VersionId
    WHERE r.RoleId NOT IN ('NEW_HIRE', 'LEAVER')
    GROUP BY r.RoleId
)
SELECT
    (SELECT COUNT_BIG(*) FROM RoleSizes) AS BusinessRoles,
    (SELECT COUNT_BIG(*) FROM src.RoleVersion rv
        JOIN src.RoleEntitlement re ON re.VersionId = rv.VersionId
        WHERE rv.ValidTo IS NULL AND rv.RoleId NOT IN ('NEW_HIRE', 'LEAVER')) AS PresentRoleEntitlementLinks,
    (SELECT COUNT_BIG(*) FROM src.Entitlement) AS Entitlements,
    (SELECT COUNT_BIG(*) FROM src.Application) AS Applications,
    (SELECT COUNT_BIG(*) FROM src.Entitlement e
        LEFT JOIN src.Application a ON a.ApplicationId = e.ContextCode
        WHERE a.ApplicationId IS NULL) AS EntitlementsWithoutApplication,
    (SELECT MIN(PresentEntitlements) FROM RoleSizes) AS MinEntitlementsPerRole,
    (SELECT MAX(PresentEntitlements) FROM RoleSizes) AS MaxEntitlementsPerRole,
    (SELECT COUNT_BIG(*) FROM RoleSizes WHERE PresentEntitlements = 0) AS RolesWithoutEntitlements,
    (SELECT COUNT_BIG(*) FROM src.GroupMap) AS VerifiedGroupMappings;
'@
.\scripts\Invoke-RpSql.ps1 -NamesFile .\names.json -Query $query | Format-List
```

For the current lab snapshot, expect **75** business roles, **806** present role-entitlement links, **250** entitlements, **40** applications, **0** unmapped entitlement-to-application links, and no role with zero present entitlements. Present entitlement counts range from **8 to 12** per role. The **0** verified group mappings are expected in this synthetic demo; group mappings are not required for the first X-Ray release.

#### D7.2 Add Role X-Ray to the main view and role drawer

1. Edit `web\app.js`; do not edit generated files under `web\dist` by hand. The existing drawer is created in `role(id)`. Its catalog state is populated by `loadCatalog()`, and `table(rows, cols)` can render the inventory using the portal's existing table pattern.
2. Add a main-page view mode:
   - Add `xray` to the `viewMode` state and insert the **Role X-Ray** button in `renderOverviewDashboard()` between **Detailed View** and **Role Differentiator**.
   - Add its click handler and a `viewMode === 'xray'` render branch that calls `renderRoleXRayOverview(container)`.
   - Keep the simple, detailed, and differentiator view modes and their behavior unchanged. Let the segmented switcher wrap on narrow screens so the additional button does not overflow.
3. Implement `renderRoleXRayOverview(container)` with a search box and a role dropdown:
   - Populate options from `allRoles` returned by the authenticated overview; include only business roles that have a matching `ROLE_ENTITLEMENT_BLUEPRINTS` entry. Do not build the selectable list from the unfiltered baseline catalog.
   - Show the role title, region, cost center, and role ID in each option. Search should filter by title, ID, region, or cost center, and selecting an option should render that role's inventory.
   - Select `demo.primaryA` initially when it is present in the authorized list; otherwise select the first matching role. If the search has no matches, show a clear no-results message.
   - Call the same read-only `renderRoleXRay(container, roleId)` renderer used by the drawer; do not duplicate the entitlement-to-application mapping logic.
4. Preserve the current role and entitlement sources:
   - `ROLE_ENTITLEMENT_BLUEPRINTS[roleId].entitlements` is the selected role's list of entitlement IDs. The live catalog supplies present-in-role links; do not add `Present_In_Role_Flag = 'N'` rows.
   - `ENTITLEMENT_CATALOG[entitlementId]` supplies entitlement details.
   - The live SQL catalog uses entitlement `ContextCode` as the `ApplicationId`. Resolve that ID using `cat.applications`; do not infer an application from an entitlement name or ID.
5. In `loadCatalog()`, retain an application lookup keyed by `ApplicationId` with its `Name` and `Category`. Keep the existing `APPLICATION_NAMES` behavior because other views use it. When building a live `ENTITLEMENT_CATALOG` entry, also retain its `EntitlementId`, `DisplayName`, and `ContextCode`/application ID and associate the resolved application name and category. Preserve the existing `name`, `risk`, `applications`, and `description` properties used by other views; add fields rather than replacing those properties with an incompatible shape.
6. In `role(id)`, add a **Role X-Ray** button and a separate `.drawer-body` container. Append the new tab after the existing tabs. Keep **Evidence & Complaints** active initially. Add a X-Ray click handler that activates its tab, hides the other three bodies, and calls `renderRoleXRay(xrayBody, id)`. Update the existing tab handlers only as needed to deactivate the new tab and hide the X-Ray body; their current behavior and default must remain unchanged.
7. Implement `renderRoleXRay(container, roleId)` as a separate, read-only renderer:
   - Clear the container before rendering and handle a missing role/catalog entry with a visible message.
   - Read and de-duplicate the role's entitlement IDs, resolve each ID through `ENTITLEMENT_CATALOG`, then resolve its application using the stored application ID.
   - Build one row per role-entitlement link with **Entitlement ID | Entitlement | Application | Category**. The application must appear on the same row as its entitlement so the stakeholder can follow the requested hierarchy. Each current entitlement maps to one application; use a single app value in the current UI.
   - Sort the display consistently, such as by application name and then entitlement name. Provide an empty-state message if the role has no present entitlements. If an entitlement or application cannot be resolved, display a clear data-quality warning for that row; do not silently substitute a guessed value.
   - Build row objects with keys such as `EntitlementId`, `EntitlementName`, `ApplicationName`, and `ApplicationCategory`, then pass matching key/label pairs to `table(rows, cols)`. The helper uses text nodes; if building custom markup, use `text()`/`escapeHtml()` for all dynamic values and do not interpolate catalog values into unescaped `innerHTML`.
8. Keep the X-Ray separate from evidence and actions. It must not display tickets, employee records, peer evidence, cases, or simulation results, and must not make an additional API call or write to SQL. The drawer's existing role call remains for the existing features; both X-Ray entry points should consume the already-loaded catalog only.
9. Do not label generated `SG-<ApplicationId>-<EntitlementId>` strings as verified AD/Entra groups. The current database has no verified `src.GroupMap` entries. Do not add group labels to this view unless a trusted group-to-entitlement mapping source is populated; if added later, label its source and verification status.

#### D7.3 Build the portal artifacts

Run these from the repository root after changing `web\app.js`:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\web\Build-Catalog.ps1 -DatasetDir .\datasets -NamesFile .\names.json
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\web\Build-App.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\web\Build-Html.ps1 -ConfigFile .\web\config.json
```

These commands regenerate the catalog and portal bundle using the existing lab configuration. Do not commit or deploy a `web\dist\index.html` built from another environment’s configuration.

#### D7.4 Validate the X-Ray and regressions

1. Deploy the artifacts built in D7.3:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Deploy-WebApp.ps1
   ```

2. Open the portal from the lab network and sign in with the approved demo owner account.
3. Select the main-page **Role X-Ray** button between **Detailed View** and **Role Differentiator**. Search by part of a title or role ID, confirm the dropdown filters, and select a role.
4. Confirm the selected role's heading and entitlements update. Check both a role with 8 present entitlements and one with 12; every entitlement must show its associated application and category.
5. Open **Inspect** for a role, then select the drawer's **Role X-Ray** tab. Confirm it matches the main-page inventory for the same role.
6. Confirm no entitlement is shown as present when its source row has `Present_In_Role_Flag = 'N'`. Confirm there are no blank or unresolved applications; if one appears, stop and investigate the catalog mapping rather than inventing a fallback app.
7. Confirm the X-Ray contains no ticket, employee, evidence, or decision data. Confirm group information is absent or clearly marked as not mapped; do not present generated group labels as live directory records.
8. Switch back through **Evidence & Complaints**, **Policy What-If Studio**, and **Role Differentiator**. Verify their existing behavior is unchanged and that opening X-Ray does not create a SQL record or submit a request.
9. From the lab network, rerun the existing automated validation:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Test-t020Validation.ps1 -SingleOwnerDemo
   ```

   This regression suite does not replace the manual X-Ray checks above; it confirms the existing single-owner deployment and gateway behavior still pass.

---

## 10. Phase 5: Verification, Validation & Live Demo (Whole Team)

**Owner:** Whole Team  

**Duration:** ~15 minutes  

**Goal:** Demonstrate the assessment over the synthetic 600-ticket / 75-role dataset, execute applicable validations, and deliver the hackathon presentation. ADF and live Entra collection are not required for the single-owner synthetic demo.

### Step 5.1: Run Assessment on Hackathon Dataset

1. **Single-owner synthetic demo: skip live Entra collection.** The demo intentionally uses the imported synthetic dataset; it does not claim to show current Entra memberships.

2. The assessment has already been published directly from SQL for this lab. If the synthetic dataset or SQL procedures change, republish it from the lab workstation (ADF is unavailable):

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Apply-PortalApi.ps1 -AssessOnly -Direct

   ```
3. **Sanity-check the ranking against the synthetic assessment.** Confirm the leading roles using the portal or `SELECT TOP 5 ... FROM core.Impact`. For the single-owner demo, use Owner A's approved account and explain that the ranking/evidence is synthetic, not live Entra telemetry.
### Step 5.2: Execute Automated Test Suite

Run the automated validation suite. Every expectation is derived from `names.json` and the CSVs in `.\datasets` (row counts, owners, roles, search document count) — nothing is hard-coded; it also checks the Azure resources, the portal, the published assessment and that the deployed gateway(s) reject anonymous callers. For this one-owner/no-ADF demo, pass `-SingleOwnerDemo`:
```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Test-t020Validation.ps1 -SingleOwnerDemo

```
> [!NOTE]
> Run it from the lab network after Step D6 (it calls the private SQL, Search and Web App endpoints). The legacy copy that asserted the sample app's topology is in `.\legacy\scripts\`.
---

### Step 5.3: Hackathon Demo Choreography (The Winning GM Financial Pitch)

Follow this 6-step sequence when presenting to hackathon judges:
```
[1. Executive Overview]  -->  [2. Evidence Deep-Dive]  -->  [3. Policy What-If Studio]  -->  [4. ServiceNow Remediation]  -->  [5. AI Semantic Search]  -->  [6. Role Differentiator]
(75 Roles, 3 Countries)       (600 Tickets / 175 Movers)   (Zero-Friction Simulation)      (End-to-End Governance Hand-off) (Intent-Matched Discovery)      (Cross-Border Gap Analysis)
```



1. **Step 1: The Problem & Portfolio Pulse (1 Minute)**

   * Open the live portal at **`$names.WebUrl`** (from a lab-network machine; private endpoint only).

   * Point out the portfolio overview: **75 Business Roles monitored across US, Canada, and Mexico**.

   * Highlight the top frictional roles identified in the dataset — with the current lab dataset **Application Access Liaison `BR0065` (US, Owner A)** and **Governance Controls Specialist `BR0013` (Canada, Owner B)** (`names.OwnerARoleId` / `OwnerBRoleId`; confirm in the `Rank` column) — due to verified post-transfer access request tickets.

   * *Streamlined Simple View UX:* The portfolio dashboard features a high-impact, noise-reduced table layout:
     - **`Rank`**: Priority ranking based on verified friction ratio.
     - **`Role & Department`**: Job title, business division, country, role ID, and active remediation tracking badges.
     - **`Impact`**: High-signal impact metrics (e.g., `4 Impact Instances · 4 Frictional Movers · 4 Verified Tickets`). Renamed to **`IMPACT`** with the redundant engine status column removed to maximize executive focus.
     - **`Action`**: Immediate `Inspect & Fix` access drawer launcher.

   * *Key Talking Point:* "When employees move between branches and departments, they face immediate access friction. Role Patrol autonomously audits 600 manual tickets against 175 JML events to identify the exact roles causing business downtime."



2. **Step 2: Deterministic Evidence Drawer & 5 Grounded Pillars of Proof (1 Minute)**

   * Click **Inspect** on the top frictional role of the signed-in owner (`names.OwnerARoleId` or `names.OwnerBRoleId`; currently `BR0065` or `BR0013`).

   * *UX Polish:* The drawer opens seamlessly with zero disruptive banner notifications, focusing attention immediately on the **5 Grounded Pillars of Proof** under the Evidence Summary:
     - **Pillar 1 · Root Cause Role Defect**: Explicitly isolates the primary missing entitlement and access level causing mover transfer friction (for `BR0065` in the current dataset: `ENT0209 Core Agent` and `ENT0029 View User`; for `BR0013`: `ENT0028 Admin Viewer`).
     - **Pillar 2 · Target Application Scope**: Identifies affected enterprise software platforms, target SaaS systems, and core databases (e.g., `Review Lantern (APP...)` for `ENT0209`, `Reconcile Ridge` for `ENT0029` / `ENT0028` — names come from `APPLICATION_MASTER.csv`).
     - **Pillar 3 · Verified Employee Complaints**: Lists verified post-transfer complaint tickets filed by affected employees with direct verbatim quotes.
     - **Pillar 4 · Peer Group Prevalence Benchmark**: Highlights empirical peer adoption benchmarks and live Entra ID group membership prevalence across colleagues in the same role.
     - **Pillar 5 · Upcoming Mover Projections**: Projects upcoming scheduled employee transfers into this role to prevent day-one outages before they occur.

   * *Visual Breathing Room:* Generous spacing (16px vertical gap) and crisp typography ensure each pillar communicates clear audit proof with zero visual noise.

   * *Key Talking Point:* "Every insight is backed by deterministic SQL ledger rows and real Entra ID group membership snapshots—not speculative AI text."



3. **Step 3: Policy What-If Studio (1.5 Minutes)**

   * Switch to the **Policy What-If Studio** tab.

   * Select the missing required entitlement identified in the evidence drawer.

   * Run the simulation: demonstrate how proactively granting this entitlement upon role assignment reduces the projected friction score to zero for upcoming movers.

   * *Key Talking Point:* "Before an IAM architect commits a policy change, they can simulate its impact against historical transfer cohorts with zero risk."



4. **Step 4: Submit ServiceNow Request & Governed IAM Remediation (1.5 Minutes)**

   * Inside the **Inspect & Fix** drawer (or right after running a policy simulation in the **Policy What-If Studio**), click **`⚡ Submit ServiceNow Request →`**.

   * The enterprise **ServiceNow Service Catalog Item Modal** opens:
     - Review the **5 Triangulated Pillars Attached Evidence Dossier** and **Pillar 2 Target Applications**.
     - Confirm the pre-populated audit business justification and **SoD Pre-Flight Status (✅ Passed - 0 Violations)**.
     - Click **`🚀 Submit 'Business Role Modification request'`**.

   * Verify the **ServiceNow Request Submitted Successfully** card:
     - **ServiceNow Request #:** `REQ00xxxxxx`
     - **Requested Item (RITM):** `RITM00xxxxxx`
     - **Fulfillment Task:** `SCTASK00xxxxxx`
     - **Governed Target System:** SailPoint IdentityIQ Blueprint Sync
     - **Workflow State:** `⏳ Work in Progress`

   * Click **Return to Role Patrol** and demonstrate continuous remediation tracking:
     - The **Evidence Drawer header** displays the active badge: `🔄 ServiceNow RITM00xxxxxx (+ Add ENT...)`.
     - The **top of the Evidence body** displays the green banner: `🔄 Active Remediation Request: ServiceNow RITM00xxxxxx`.
     - The **Overview Portfolio Table** tracks the active `🔄 RITM00xxxxxx` badge on that role row.

   * *Key Talking Point:* "Role Patrol doesn't stop at diagnosing access friction—it bridges directly into enterprise IAM governance by generating an end-to-end ServiceNow service catalog item with audit dossiers for SailPoint role blueprint updates."



5. **Step 5: Demonstrating Azure AI Semantic Search (1 Minute)**

   * Click **AI Search** in the top navigation bar.

   * **Query 1 (Natural Language Intent Matching):**
     * Enter: `missing admin reader access` or `missing permission` (the portal's quick-query chips are generated from the dataset by `Build-Catalog.ps1`)
     * *Observation:* Notice the query contains zero technical codes or ticket numbers. Azure AI Search matches the business intent, surfacing tickets requesting the matching entitlement (for example `Admin Viewer` in `Reconcile Ridge`) with high semantic relevance.

   * **Query 2 (Job Function & Access Defect Discovery):**
     * Enter the job title of an owner's role, e.g. `Application Access Liaison missing access` or `Governance Controls Specialist missing access`
     * *Observation:* Instantly surfaces candidate frictional tickets for that role (`BR0065` / `BR0013` and its peers in other countries), displaying application category, request priority, and mover confirmation status.

   * *Key Talking Point:* "Azure AI Search isn't just matching strings—it indexes the complete semantic context of business roles, entitlements, and target applications. Candidate hits are verified directly against Azure SQL for deterministic audit attribution."

6. **Step 6: Role Differentiator & Multi-Insight Gap Analysis (1 Minute)**

   * Click **⚖️ Role Differentiator** in the top view mode switcher (or click Tab 3 inside any role's inspection drawer).

   * Click the first quick preset chip (generated from the dataset, same job title in two countries): currently **`Application Access Liaison: US (BR0065) ↔ CA (BR0015)`** (or select any pair among the 75 business roles in the dropdowns).

   * *Observation & Multi-Insight Layout:* 
     - The diff engine instantly calculates divergence across regions with an intuitive 3-tab layout:
       1. **`🔑 Entitlements`**: Granular discrepancy cards with color-coded borders (+ green for missing in Role A, − red for exclusive to Role A, gray for shared baseline), displaying application tags, AD group pills, risk levels, and direct **`+ Req`** ServiceNow buttons.
       2. **`👥 AD Security Groups`**: Direct mapping of Active Directory / Microsoft Entra Security Groups (`SG-APP...-ENT...`) synchronized through identity access packages and lifecycle workflows.
       3. **`💻 Application Access`**: Enterprise software systems comparison grid highlighting platforms exclusive to Role B, platforms exclusive to Role A, and shared systems with permission depth differences.
     - Evaluators can click **`+ Req`** on any missing item to immediately launch the pre-populated ServiceNow remediation modal!

   * *Key Talking Point:* "When roles exist across multiple operating regions, cross-border transfers often fail due to regional entitlement divergence. Role Differentiator provides instant side-by-side gap analysis across entitlements, AD groups, and applications with one-click ServiceNow catalog remediation."



---



## 11. Troubleshooting & Dataset FAQ



### Q1: Cannot connect to Azure SQL ("Client with IP address ... is not allowed", timeout, or public IP resolved)

* **Cause:** The lab SQL server has **public network access Disabled** and is only reachable through its private endpoint (10.0.58.94). The database is Standard S0 (not Serverless), so it does not auto-pause.

* **Fix:** Run from a machine on the lab network (Cloud PC / VPN). Do **not** add firewall rules or enable public access. Verify:

  ```powershell
  Resolve-DnsName "$($names.SqlServer).database.windows.net" | Where-Object { $_.IPAddress }   # expect 10.0.58.94
  Test-NetConnection "$($names.SqlServer).database.windows.net" -Port 1433 -InformationLevel Quiet   # expect True
  az sql db show -g $names.SqlResourceGroup -s $names.SqlServer -n $names.Database --query status -o tsv   # expect Online

  ```



### Q2: Managed Identity Login Fails (`Login failed for user '<token-identified principal>'`)

* **Cause:** Azure SQL external users created via `WITH SID=..., TYPE=E` require the **Application (Client) ID** converted to binary hex (`0x...`), **NOT** the Object ID.

* **Fix:** Verify you used `Get-SidHex` with the Service Principal's `appId`:

  ```powershell
  $spAppId = (az ad sp show --id $principalId --query appId -o tsv)

  Get-SidHex $spAppId

  ```



### Q3: Assessment Pipeline throws `Ticket clock invalid`

* **Cause:** The dataset has tickets timestamped after `@BusinessAsOf`.

* **Fix:** Ensure `@BusinessAsOf` in ADF pipeline or SQL query is set to `'2026-10-01T12:00:00'` or higher:

  ```sql
  DECLARE @maxTicket datetime2 = (SELECT MAX(OpenedAt) FROM src.Ticket);
  DECLARE @RunId uniqueidentifier = NEWID();

  EXEC core.usp_Assess @RunId = @RunId, @BusinessAsOf = @maxTicket;

  ```



### Q4: Entra collection throws `Unknown/non-user group member`

* **Cause:** A member in an Entra ID group is missing from `src.IdentityMap`.

* **Fix:** Ensure all Entra users assigned to mapped groups exist in `src.IdentityMap`. Running `Import-DirectoryFromDataset.ps1` automatically synchronizes all users and groups.



### Q5: Portal MSAL popup gets blocked or infinite redirect loop

* **Cause:** The Web App hostname or `bridge.html` is not registered in the Entra ID SPA App Registration, or the browser is not on the lab network (the portal is private-only).

* **Fix:** In Entra ID > App Registrations > `t020_RolePatrol-Browser-<suffix>` > Authentication, ensure `https://<web-app-host>.azurewebsites.net/bridge.html` is listed under **Single-page application** Redirect URIs (not Web), and open the portal from a Cloud PC / VPN session.



### Q6: `npm` or `registry.npmjs.org` is blocked by the Hackathon Lab network

* **Cause:** Corporate security proxies often block external package registries (`registry.npmjs.org`) or restrict execution of Node.js package managers.

* **Fix (Zero-NPM Fallback Plan):**
  1. **Do not run `npm ci` or `npm run build`:** use `Build-Catalog.ps1`, `Build-App.ps1` and `Build-Html.ps1` (Step D5) — they need only PowerShell. `web/dist/app.js` is rebuilt from the vendored MSAL code plus the generated catalog and `app.js`. Never deploy a `web\dist\index.html` that was not built with this lab's `config.json` (`Deploy-WebApp.ps1` checks this).
  2. **Direct Web App Deployment:** Run the zip deployment in Step D6 directly to publish `web/dist` to the portal Web App without touching `npm`.
  3. **Build elsewhere:** Build `web/dist` on a machine with npm access and copy the folder to the lab workstation (SWA / GitHub Actions deployment is not used in this lab).
  4. **PowerShell module blocked:** If `Install-Module SqlServer` fails, copy the module folder from another machine into `$HOME\Documents\PowerShell\Modules`, or run the `.sql` files through `System.Data.SqlClient` with an access token (verified working on the lab image).



### Q7: Graph / Azure CLI returns `InteractionRequired ... LocationConditionEvaluationSatisfied`

* **Cause:** Conditional Access / Continuous Access Evaluation rejected the token: either it was used from a different location/machine, or the operation needs **MFA** (`AADSTS50076`; Azure Resource Manager writes such as `az group create`, `az webapp create` and `az datafactory create` trigger this). This is a sign-in challenge, **not** a permissions denial.

* **Fix:** Re-authenticate using the exact command printed in the error (it carries the claims challenge) and complete MFA in the browser:

  ```powershell
  az logout
  az login --tenant "1c3bd3e8-1b6d-423a-a3e4-813b1f3f6619" --scope "https://management.core.windows.net//.default" --claims-challenge "<claims value printed in the error>"

  ```
  For Graph challenges run `az logout; az login --tenant gmfdev.onmicrosoft.com` from a lab-network machine (use `--use-device-code` if the Windows account picker fails with "logon session does not exist"; if that still fails run `az config set core.enable_broker_on_windows=false` first), then retry. Run all Graph steps (Tracks A and D3) from that same session.



### Q8: ADF cannot connect to SQL (managed private endpoint `Pending` / pipeline fails with network error)

* **Cause:** The managed private endpoint to the SQL server must be approved on the SQL side, and the linked service must use the Managed VNet IR.

* **Fix:**

  ```powershell
  $sqlId = az sql server show -g $names.SqlResourceGroup -n $names.SqlServer --query id -o tsv
  az network private-endpoint-connection list --id $sqlId --query "[].{id:id,state:properties.privateLinkServiceConnectionState.status}" -o table
  az network private-endpoint-connection approve --id <connection-id> --description "Role Patrol ADF"

  ```
  Confirm the `RolePatrolSql` linked service has `connectVia = ManagedVnetIR` (Step C1). As a fallback, run `core.usp_Ingest` / `core.usp_Assess` directly from the workstation (Q3).



### Q9: Web App returns 403 / name does not resolve / `az webapp deploy` fails

* **Cause:** Web Apps have public access disabled and are reachable only through their private endpoints; DNS must resolve through the linked `privatelink.azurewebsites.net` zone.

* **Fix:** Resolve `<app>.azurewebsites.net` and `<app>.scm.azurewebsites.net` from the lab network (expect `10.0.58.x`). If they resolve publicly, re-run the `dns-zone-group` command in Step C3. If the VNet integration subnet is rejected, confirm it is delegated to `Microsoft.Web/serverFarms` and not already used by another plan (try `appservice-functions-subnet`).



---



## 12. Repository Layout & Script Status for this Lab

The repository is the sample app's code base adapted to this lab and its dataset (`.\datasets`). Everything the guide calls is present in the working folder; scripts that only made sense for the original public, blank-slate topology were moved to `.\legacy\` (kept for reference, never called by the guide).

| File | Status | What changed |
|---|---|---|
| `names.json` | **Regenerated** | Steps 0.2 / 0.2b: lab resource names, one RG per resource, `Owner*` fields; written by the guide, not committed from another subscription. |
| `scripts\Select-RoleOwners.ps1` | **New** | Picks Owner A (US) / Owner B (Canada) from the dataset and stores them in `names.json` (Step 0.2b). |
| `scripts\Invoke-RpSql.ps1` | **New** | Runs T-SQL over the private endpoint with your Entra token; renders `__OWNER_A_GID__`, `__OWNER_B_GID__`, `__API_A__`, `__API_B__`, `__FACTORY__` (+ SIDs) tokens from `names.json` and fails on any unresolved token. |
| `sql\06_permissions.sql`, `08_portfolio_access.sql`, `09_enable_evaluator_actions.sql` | **Updated** | Owner GIDs are tokens instead of the sample app's hard-coded people; no Collector principal; `06` aborts if an owner owns no role. |
| `Import-DirectoryFromDataset.ps1` (root) | **Updated** | `-OwnerGids` (default from `names.json`); group membership now uses `ROLE_ASSIGNMENTS.csv` (Active) + `ROLE_ENTITLEMENTS.csv` (`Present_In_Role_Flag = Y`) — the old file names were silently skipped, so no memberships would have been created. |
| `scripts\Import-HackathonDatasets.ps1`, `search\Deploy-Search.ps1`, `web\Build-Catalog.ps1`, `scripts\Select-RoleOwners.ps1` | **Updated** | Accept `ACCESS_REQUEST_TICKETS.csv` **or** `MOCK_ACCESS_TICKETS.csv`. |
| `search\Deploy-Search.ps1` | **Updated** | Uses `SearchResourceGroup` / `SqlResourceGroup`; no managed-identity change or SQL indexer on the shared service unless `-UseSqlIndexer`; fails if the tickets CSV is missing. |
| `scripts\Deploy-Entra.ps1`, `scripts\Set-OwnerCredentials.ps1` | **Updated** | Use `WebUrl` and `OwnerAGid` / `OwnerBGid`. |
| `scripts\Apply-PortalApi.ps1` | **Rewritten** | `-SkipAssess` (Track B), `-AssessOnly`, `-Direct` (assessment without Data Factory); loads `src.Application` (required by `api.usp_Catalog`). |
| `scripts\Deploy-AppServiceGateway.ps1` + `gateway\` (Node 20, `tedious`) | **New** | Replaces the Logic App gateways: Entra token policy (unit-tested offline), MSI → `api.usp_Gateway`, semantic/lexical ticket search, CORS; writes `web\config.json`. |
| `scripts\Deploy-WebApp.ps1` | **New** | Zip-deploys the portal; refuses a build that lacks this lab's tenant/SPA client ID. |
| `scripts\Test-t020Validation.ps1` | **Rewritten** | Data-driven checks (dataset counts, owners, Search count, Web Apps, anonymous-access rejection). |
| `web\Build-Catalog.ps1`, `web\Build-App.ps1`, `web\vendor\msal-bundle.js`, `web\demo-config.json` | **New** | Regenerate `catalog-data.js` and the demo settings from the dataset; build `dist\app.js` without npm. |
| `web\app.js`, `web\ticket-search-ui.js`, `web\Build-Html.ps1` | **Updated** | Owner hints, Role Differentiator presets, quick searches and departments come from `window.RP_CONFIG.demo`; no hard-coded roles/people. `web\dist\index.html` / `bridge.html` of the sample app were removed (another tenant's IDs). |
| `legacy\` | **Moved** | `Deploy-LogicApps`, `Deploy-LogicAppGateway`, `Test-LogicAppCors`, `Deploy-Swa`, `deploy-swa`, `Deploy-t020`, `Deploy-Team20`, `Test-Team20Validation`, old `Test-t020Validation` / `Apply-PortalApi` / `Import-DirectoryFromDataset`, `Invoke-Team20Sql`, `Check-AuditItems`, `check-live`, `init-names`, root `Import-HackathonDatasets`, `plan.md`, `adf_user.sql`, `logic_app_users.sql`, `seed_*.py`, rendered/stale JSON and the Logic App templates `sql-api-connection.json` / `basic-workflow.json`. |
| `templates\logicapp-api-workflow.json` | **Reference only** | Behavioural spec for the gateway contract. |
| `templates\adf-sql-linkedservice.json`, `sql\01`–`05`, `07` | **No change** | `connectVia` is injected inline in Step C1; no database name is hard-coded. |

> [!WARNING]
> **Not verifiable from the authoring machine (confirm in the lab):** (1) your Entra rights for creating users / granting consent (Step 0.1); (2) that `vnet-integration-subnet` is free; (3) globally unique `*.azurewebsites.net` names; (4) the gateway's SQL/Search calls and the App Service build of `tedious` (the token policy has offline tests; the data path needs the lab network); (5) that the engine's own top-friction roles match the owners chosen from the ticket proxy (Step 5.1 item 3).
