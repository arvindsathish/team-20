<#
.SYNOPSIS
    Regenerates the portal's baseline catalog and demo configuration from the hackathon dataset.
.DESCRIPTION
    Reads .\datasets (the lab dataset) and names.json and writes
      web\catalog-data.js   BASELINE_APPLICATIONS / BASELINE_ENTITLEMENTS / BASELINE_ROLES (instant-render baseline;
                            the live api.usp_Catalog response still overrides it in the browser)
      web\demo-config.json  owner sign-in hints, Role Differentiator preset pairs and quick-search chips,
                            merged into window.RP_CONFIG by web\Build-Html.ps1
    Nothing is hard-coded: roles, entitlements, applications, owners and presets all come from the CSVs and names.json.
    Run after Select-RoleOwners.ps1 (and after Step A1 if you want sign-in hints with the real UPNs).
#>
[CmdletBinding()]
param(
    [string]$DatasetDir = "..\datasets",
    [string]$NamesFile  = "..\names.json",
    [string]$IdentityMap = "..\directory-output\identity-map.csv"
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
function Resolve-Existing([string]$Path, [switch]$Optional) {
    foreach ($c in @($Path, (Join-Path $PWD $Path), (Join-Path $scriptDir $Path))) {
        if ($c -and (Test-Path -LiteralPath $c)) { return (Resolve-Path -LiteralPath $c).Path }
    }
    if ($Optional) { return $null }
    throw "Path not found: $Path"
}

$datasets  = Resolve-Existing $DatasetDir
$names     = Get-Content -LiteralPath (Resolve-Existing $NamesFile) -Raw | ConvertFrom-Json
$idMapPath = Resolve-Existing $IdentityMap -Optional
if (-not $names.OwnerAGid) { throw "names.json has no OwnerAGid/OwnerBGid - run scripts\Select-RoleOwners.ps1 first." }

$apps    = Import-Csv (Join-Path $datasets "APPLICATION_MASTER.csv")
$ents    = Import-Csv (Join-Path $datasets "ENTITLEMENT_CATALOG.csv")
$roles   = Import-Csv (Join-Path $datasets "BUSINESS_ROLE_MASTER.csv")
$roleEnt = Import-Csv (Join-Path $datasets "ROLE_ENTITLEMENTS.csv")
$ticketCsv = @("ACCESS_REQUEST_TICKETS.csv", "MOCK_ACCESS_TICKETS.csv") | ForEach-Object { Join-Path $datasets $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $ticketCsv) { throw "No tickets CSV (ACCESS_REQUEST_TICKETS.csv or MOCK_ACCESS_TICKETS.csv) in $datasets" }
$tickets = Import-Csv $ticketCsv

$appById = @{}
foreach ($a in $apps) { $appById[$a.Application_ID] = $a }

# Non-ASCII separators are built from code points so the script is safe in Windows PowerShell 5.1 (no BOM)
$dot   = [string][char]0x00B7
$arrow = [string][char]0x2194

# UI grouping only: the dataset has no department column, so group role titles by keyword.
function Get-Department([string]$Title) {
    switch -Regex ($Title) {
        'Certification|Review|Audit'                  { return 'Access Certification & Audit' }
        'Policy|Controls|Compliance|Segregation|Reporting' { return 'Governance & Controls' }
        'Role |Catalog'                               { return 'Role Engineering' }
        'Joiner|Workforce|Contractor'                 { return 'Workforce Lifecycle' }
        'Privileged'                                  { return 'Privileged Access' }
        'Directory|Operations|Provisioning|Liaison'   { return 'Access Operations' }
        'Identity'                                    { return 'Identity Governance' }
        default                                       { return 'Operations' }
    }
}
function Get-Region([string]$Group) {
    switch ($Group) { 'GM Financial US' { 'US' } 'GM Financial Canada' { 'CA' } 'GM Financial Mexico' { 'MX' } default { 'US' } }
}

$baseApps = [ordered]@{}
foreach ($a in ($apps | Sort-Object Application_ID)) {
    $baseApps[$a.Application_ID] = [ordered]@{ id = $a.Application_ID; name = $a.Application_Name; category = $a.Application_Category }
}

$baseEnts = [ordered]@{}
foreach ($e in ($ents | Sort-Object Entitlement_ID)) {
    $app  = $appById[$e.Application_ID]
    $high = $e.Access_Level -in @('Elevated', 'Administrative')
    $baseEnts[$e.Entitlement_ID] = [ordered]@{
        entitlementId = $e.Entitlement_ID
        name          = "$($e.Entitlement_Name) ($($e.Application_ID))"
        displayName   = $e.Entitlement_Name
        appId         = $e.Application_ID
        appName       = $app.Application_Name
        appCategory   = $app.Application_Category
        adGroup       = "SG-$($e.Application_ID)-$($e.Entitlement_ID)"
        risk          = $(if ($high) { "High Risk $dot Privileged Access" } else { "Standard Risk $dot Pre-Approved" })
        accessLevel   = $e.Access_Level
        applications  = @($app.Application_Name)
        description   = "$($e.Entitlement_Name) permission within $($app.Application_Name) ($($e.Application_ID))."
    }
}

# Current role blueprint = entitlements flagged present in the role (same rule Import-HackathonDatasets.ps1 loads into SQL)
$entsByRole = @{}
foreach ($re in $roleEnt) {
    if ($re.Present_In_Role_Flag -eq 'Y') {
        if (-not $entsByRole.ContainsKey($re.Business_Role_ID)) { $entsByRole[$re.Business_Role_ID] = New-Object System.Collections.Generic.List[string] }
        $entsByRole[$re.Business_Role_ID].Add($re.Entitlement_ID)
    }
}

$baseRoles = [ordered]@{}
foreach ($r in ($roles | Sort-Object Business_Role_ID)) {
    $region = Get-Region $r.Business_Group
    $list = @()
    if ($entsByRole.ContainsKey($r.Business_Role_ID)) { $list = @($entsByRole[$r.Business_Role_ID] | Sort-Object -Unique) }
    $baseRoles[$r.Business_Role_ID] = [ordered]@{
        roleId          = $r.Business_Role_ID
        title           = "$($r.Title) ($region) $dot $($r.Business_Role_ID)"
        jobTitle        = $r.Title
        department      = Get-Department $r.Title
        region          = $region
        costCenter      = $r.Cost_Center
        description     = "$($r.Title) in $region (Cost Center $($r.Cost_Center))."
        entitlements    = $list
        ownerEmployeeId = $r.Role_Owner_GID
        canDecide       = 1
        canIam          = 0
    }
}

function ConvertTo-JsLiteral($obj) { ($obj | ConvertTo-Json -Depth 8) }
$js = @"
// Baseline enterprise catalog GENERATED by web\Build-Catalog.ps1 from the lab dataset (.\datasets) - do not edit by hand.
// $($apps.Count) applications, $($ents.Count) entitlements, $($roles.Count) business roles. The live api.usp_Catalog response overrides this in the browser.

export const BASELINE_APPLICATIONS = $(ConvertTo-JsLiteral $baseApps);

export const BASELINE_ENTITLEMENTS = $(ConvertTo-JsLiteral $baseEnts);

export const BASELINE_ROLES = $(ConvertTo-JsLiteral $baseRoles);
"@
[IO.File]::WriteAllText((Join-Path $scriptDir 'catalog-data.js'), $js, [Text.UTF8Encoding]::new($false))

# ---- Demo configuration (owner hints, differentiator presets, quick searches) ----
$friction = @{}
$entFriction = @{}
foreach ($t in $tickets) {
    if ($t.Request_Type -eq 'Missing Role Access' -and $t.Present_In_Role_At_Request -eq 'N') {
        $friction[$t.Business_Role_ID] = 1 + [int]$friction[$t.Business_Role_ID]
        if ($t.Entitlement_ID) { $entFriction[$t.Entitlement_ID] = 1 + [int]$entFriction[$t.Entitlement_ID] }
    }
}
$roleById = @{}
foreach ($r in $roles) { $roleById[$r.Business_Role_ID] = $r }

# Peer = same job title in another country (cross-border gap analysis)
function Get-Peer([string]$RoleId, [string]$PreferGroup) {
    $r = $roleById[$RoleId]
    $peers = $roles | Where-Object { $_.Title -eq $r.Title -and $_.Business_Role_ID -ne $RoleId }
    $pick = $peers | Where-Object { $_.Business_Group -eq $PreferGroup } | Select-Object -First 1
    if (-not $pick) { $pick = $peers | Select-Object -First 1 }
    $pick
}
function New-Pair($RoleA, $RoleB) {
    $a = $roleById[$RoleA]; $b = $roleById[$RoleB]
    [ordered]@{ a = $RoleA; b = $RoleB; label = "$($a.Title): $(Get-Region $a.Business_Group) ($RoleA) $arrow $(Get-Region $b.Business_Group) ($RoleB)" }
}

$pairs = New-Object System.Collections.Generic.List[object]
$seen  = @{}
function Add-Pair($RoleA, $RoleB) {
    if (-not $RoleB) { return }
    $k = (@($RoleA, $RoleB) | Sort-Object) -join '|'
    if (-not $seen.ContainsKey($k)) { $seen[$k] = 1; $pairs.Add((New-Pair $RoleA $RoleB)) }
}
Add-Pair $names.OwnerARoleId (Get-Peer $names.OwnerARoleId $names.OwnerBCountry).Business_Role_ID
Add-Pair $names.OwnerBRoleId (Get-Peer $names.OwnerBRoleId $names.OwnerACountry).Business_Role_ID
foreach ($rid in ($friction.Keys | Sort-Object @{ Expression = { -$friction[$_] } }, @{ Expression = { $_ } })) {
    if ($pairs.Count -ge 3) { break }
    Add-Pair $rid (Get-Peer $rid $names.OwnerBCountry).Business_Role_ID
}

$quick = New-Object System.Collections.Generic.List[object]
foreach ($rid in @($names.OwnerARoleId, $names.OwnerBRoleId)) {
    $r = $roleById[$rid]; $quick.Add([ordered]@{ label = "$($r.Title) ($rid)"; q = $r.Title })
}
foreach ($eid in ($entFriction.Keys | Sort-Object @{ Expression = { -$entFriction[$_] } }, @{ Expression = { $_ } } | Select-Object -First 2)) {
    $e = $baseEnts[$eid]; $quick.Add([ordered]@{ label = "Missing $($e.displayName) permission"; q = "missing $($e.displayName.ToLower()) access in $($e.appName)" })
}

$hints = New-Object System.Collections.Generic.List[object]
foreach ($o in @(@{ L = "$($names.OwnerACountry -replace 'GM Financial ','') Portfolio Lead"; G = $names.OwnerAGid; N = $names.OwnerAName },
                 @{ L = "$($names.OwnerBCountry -replace 'GM Financial ','') Portfolio Lead"; G = $names.OwnerBGid; N = $names.OwnerBName })) {
    $upn = $null
    if ($idMapPath) { $upn = (Import-Csv $idMapPath | Where-Object EmployeeId -eq $o.G | Select-Object -First 1).UPN }
    $hints.Add([ordered]@{ label = $o.L; gid = $o.G; name = $o.N; upn = $upn })
}

$demo = [ordered]@{
    ownerHints  = $hints
    pairs       = $pairs
    searchQuick = $quick
    primaryA    = $names.OwnerARoleId
    primaryB    = $pairs[0].b
}
[IO.File]::WriteAllText((Join-Path $scriptDir 'demo-config.json'), ($demo | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))

Write-Host ("catalog-data.js: {0} apps, {1} entitlements, {2} roles" -f $baseApps.Count, $baseEnts.Count, $baseRoles.Count) -ForegroundColor Green
Write-Host "demo-config.json: $($pairs.Count) differentiator presets, $($quick.Count) quick searches, owner hints for $($hints.Count) leads" -ForegroundColor Green
$pairs | ForEach-Object { Write-Host "  preset: $($_.label)" }
