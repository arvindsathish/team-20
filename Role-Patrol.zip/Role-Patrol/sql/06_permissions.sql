/* T20 Role Patrol - Least-Privilege Grants & Dataset Owner Permissions
   Rendered by Step C4 of the implementation guide. Tokens replaced before execution:
   __API_A__, __API_B__                         Web App managed identity names
   __API_A_SID__, __API_B_SID__                 Binary SIDs (application/client IDs as 0x...)
   __OWNER_A_GID__, __OWNER_B_GID__             Dataset role owners from names.json (OwnerAGid / OwnerBGid)
   The Collector Logic App no longer exists: Invoke-EntraCollection.ps1 runs as the signed-in db_owner. */

-- 1. Create External Users for Managed Identities using Binary Hex SIDs
IF DATABASE_PRINCIPAL_ID('__API_A__') IS NULL 
    CREATE USER [__API_A__] WITH SID=__API_A_SID__, TYPE=E;

IF DATABASE_PRINCIPAL_ID('__API_B__') IS NULL 
    CREATE USER [__API_B__] WITH SID=__API_B_SID__, TYPE=E;

-- ADF identity setup is disabled because this subscription currently denies Data Factory.
-- To resume ADF later, restore the statements below, substitute the deployed factory name
-- and its binary SID, and enable the corresponding ADF lookup/token in Step C4.
-- IF DATABASE_PRINCIPAL_ID('FACTORY_NAME') IS NULL
--     CREATE USER [FACTORY_NAME] WITH SID=ADF_BINARY_SID, TYPE=E;

-- 2. Grant Scoped Least-Privilege EXECUTE Rights
GRANT EXECUTE ON OBJECT::api.usp_Gateway TO [__API_A__];
GRANT EXECUTE ON OBJECT::api.usp_Gateway TO [__API_B__];
-- ADF-only grants; restore when ADF is approved and deployed:
-- GRANT EXECUTE ON OBJECT::core.usp_Ingest TO [FACTORY_NAME];
-- GRANT EXECUTE ON OBJECT::core.usp_Assess TO [FACTORY_NAME];

-- 3. Map Real Dataset Role Owners to the API Web Apps
-- Owner A (US lead) -> ApiA ; Owner B (Canada lead) -> ApiB
DELETE FROM core.Principal WHERE DbUser IN ('__API_A__', '__API_B__');
INSERT INTO core.Principal (DbUser, EmployeeId) VALUES ('__API_A__', '__OWNER_A_GID__');
INSERT INTO core.Principal (DbUser, EmployeeId) VALUES ('__API_B__', '__OWNER_B_GID__');

-- 4. Seed Permissions for Dataset Role Owners (decision rights only on roles they own)
DELETE FROM core.Permission WHERE EmployeeId IN ('__OWNER_A_GID__', '__OWNER_B_GID__');
INSERT INTO core.Permission (EmployeeId, RoleId, CanReadDetail, CanDecide, CanIam)
SELECT '__OWNER_A_GID__', RoleId, 1, 1, 0 FROM src.Role WHERE OwnerEmployeeId = '__OWNER_A_GID__';

INSERT INTO core.Permission (EmployeeId, RoleId, CanReadDetail, CanDecide, CanIam)
SELECT '__OWNER_B_GID__', RoleId, 1, 1, 0 FROM src.Role WHERE OwnerEmployeeId = '__OWNER_B_GID__';

IF NOT EXISTS (SELECT 1 FROM src.Role WHERE OwnerEmployeeId = '__OWNER_A_GID__')
    THROW 51000, 'Owner A (__OWNER_A_GID__) owns no role in src.Role - re-run scripts\Select-RoleOwners.ps1 and reload.', 1;
IF NOT EXISTS (SELECT 1 FROM src.Role WHERE OwnerEmployeeId = '__OWNER_B_GID__')
    THROW 51000, 'Owner B (__OWNER_B_GID__) owns no role in src.Role - re-run scripts\Select-RoleOwners.ps1 and reload.', 1;

SELECT 'Managed Identity SQL users and permissions provisioned for __OWNER_A_GID__ and __OWNER_B_GID__.' AS Result;
GO
