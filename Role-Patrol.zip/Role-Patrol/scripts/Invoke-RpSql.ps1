<#
.SYNOPSIS
    Runs T-SQL against the Role Patrol database over the private endpoint using your Entra access token.
.DESCRIPTION
    Reads SqlServer / Database / OwnerAGid / OwnerBGid from names.json. For -InputFile the following tokens are
    replaced before execution, so no owner or resource name is ever hard-coded in the .sql files:
        __OWNER_A_GID__ / __OWNER_B_GID__   names.json OwnerAGid / OwnerBGid
        __API_A__ / __API_B__ / __FACTORY__ names.json ApiA / ApiB / Factory
    Extra tokens can be supplied with -Tokens (e.g. @{ '__API_A_SID__' = '0x...' }).
    Requires the SqlServer PowerShell module (Invoke-Sqlcmd) and a network path to the SQL private endpoint.
#>
[CmdletBinding()]
param(
    [string]$Query,
    [string]$InputFile,
    [hashtable]$Tokens = @{},
    [string]$NamesFile = "..\names.json",
    [int]$QueryTimeout = 600
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$namesPath = @($NamesFile, (Join-Path $PWD $NamesFile), (Join-Path $scriptDir $NamesFile), (Join-Path $PWD "names.json")) |
    Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
if (-not $namesPath) { throw "names.json not found (looked relative to $PWD and $scriptDir)." }
$names = Get-Content -LiteralPath $namesPath -Raw | ConvertFrom-Json

if (-not $Query -and -not $InputFile) { throw "Provide -Query or -InputFile." }

$map = @{
    '__OWNER_A_GID__' = $names.OwnerAGid
    '__OWNER_B_GID__' = $names.OwnerBGid
    '__API_A__'       = $names.ApiA
    '__API_B__'       = $names.ApiB
    '__FACTORY__'     = $names.Factory
}
foreach ($k in $Tokens.Keys) { $map[$k] = $Tokens[$k] }

$tempFile = $null
if ($InputFile) {
    $path = if ([IO.Path]::IsPathRooted($InputFile)) { $InputFile } else { Join-Path $PWD $InputFile }
    if (-not (Test-Path -LiteralPath $path)) { throw "SQL file not found: $path" }
    $sql = [IO.File]::ReadAllText($path)
    foreach ($k in $map.Keys) {
        if ($sql.Contains($k)) {
            if (-not $map[$k]) { throw "Token $k is used in $InputFile but has no value (names.json incomplete?)." }
            $sql = $sql.Replace($k, [string]$map[$k])
        }
    }
    $leftover = [regex]::Matches($sql, '__[A-Z0-9_]+__') | ForEach-Object { $_.Value } | Sort-Object -Unique
    if ($leftover) { throw "Unresolved tokens in ${InputFile}: $($leftover -join ', ')" }
    $tempFile = Join-Path ([IO.Path]::GetTempPath()) ("rp-" + [guid]::NewGuid().ToString('N') + ".sql")
    [IO.File]::WriteAllText($tempFile, $sql, [Text.UTF8Encoding]::new($false))
}

try {
    $token = az account get-access-token --resource "https://database.windows.net/" --query accessToken -o tsv
    if (-not $token) { throw "Could not get an Azure SQL access token. Run az login (and complete MFA)." }
    $p = @{
        ServerInstance = "$($names.SqlServer).database.windows.net"
        Database       = $names.Database
        AccessToken    = $token
        QueryTimeout   = $QueryTimeout
        ErrorAction    = 'Stop'
    }
    if ($tempFile) { $p.InputFile = $tempFile } else { $p.Query = $Query }
    Invoke-Sqlcmd @p
}
finally {
    if ($tempFile -and (Test-Path -LiteralPath $tempFile)) { Remove-Item -LiteralPath $tempFile -Force }
}
