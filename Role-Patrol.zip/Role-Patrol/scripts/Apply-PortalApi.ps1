<#
.SYNOPSIS
    Applies the portal API layer to the Role Patrol database and (optionally) publishes the assessment.
.DESCRIPTION
    1. Runs sql/07_portal_api.sql
    2. Loads src.Application from datasets/APPLICATION_MASTER.csv
    3. Re-derives src.Ticket.ContextCode from each ticket's entitlement application (same rule as Import-HackathonDatasets.ps1)
    4. Runs sql/08_portfolio_access.sql (owner GIDs come from names.json)
    5. Publishes the assessment (core.usp_Ingest + core.usp_Assess, BusinessAsOf 2026-10-01T12:00:00):
         default  -> triggers the Data Factory pipeline RolePatrolAssessment and waits
         -Direct  -> runs the same two procedures straight from this workstation (use when the ADF managed private
                     endpoint is not approved yet)
.PARAMETER SkipAssess
    Only apply steps 1-4 (use during Track B, before Data Factory exists).
.PARAMETER AssessOnly
    Only run step 5.
.PARAMETER Direct
    Run the assessment through SQL instead of Data Factory.
#>
[CmdletBinding()]
param(
    [switch]$SkipAssess,
    [switch]$AssessOnly,
    [switch]$Direct
)

$ErrorActionPreference = 'Stop'
$root  = Split-Path -Parent $PSScriptRoot
$names = Get-Content (Join-Path $root 'names.json') -Raw | ConvertFrom-Json
$sql   = Join-Path $PSScriptRoot 'Invoke-RpSql.ps1'
$businessAsOf = '2026-10-01T12:00:00'

if (-not $AssessOnly) {
    Write-Host "Applying portal API layer to $($names.Database) ..." -ForegroundColor Cyan
    & $sql -InputFile (Join-Path $root 'sql\07_portal_api.sql') | Out-Host

    $apps = Import-Csv (Join-Path $root 'datasets\APPLICATION_MASTER.csv')
    $esc = { param($s) "'" + ([string]$s).Replace("'", "''") + "'" }
    $rows = foreach ($a in $apps) {
        $active = if ($a.Active_Status -eq 'Active') { 1 } else { 0 }
        "($(& $esc $a.Application_ID), $(& $esc $a.Application_Name), $(& $esc $a.Application_Category), $active)"
    }
    $appSql = "DELETE FROM src.Application; INSERT INTO src.Application (ApplicationId, Name, Category, Active) VALUES " + ($rows -join ",") + "; SELECT COUNT(*) AS Applications FROM src.Application;"
    & $sql -Query $appSql | Out-Host

    & $sql -Query "UPDATE t SET ContextCode = e.ContextCode FROM src.Ticket t JOIN src.Entitlement e ON e.EntitlementId = t.EntitlementId WHERE t.ContextCode <> e.ContextCode; SELECT @@ROWCOUNT AS TicketsRealigned;" | Out-Host

    & $sql -InputFile (Join-Path $root 'sql\08_portfolio_access.sql') | Out-Host
}

if (-not $SkipAssess) {
    if ($Direct) {
        Write-Host "Running core.usp_Ingest + core.usp_Assess directly (BusinessAsOf $businessAsOf) ..." -ForegroundColor Cyan
        & $sql -Query "EXEC core.usp_Ingest; DECLARE @r uniqueidentifier = NEWID(); EXEC core.usp_Assess @RunId = @r, @BusinessAsOf = '$businessAsOf';" | Out-Host
    } else {
        Write-Host "Triggering ADF pipeline RolePatrolAssessment ..." -ForegroundColor Cyan
        $runId = az datafactory pipeline create-run --factory-name $names.Factory --resource-group $names.ResourceGroup --name RolePatrolAssessment --query runId -o tsv
        if (-not $runId) { throw "Could not start the ADF pipeline. Check Step C1, or re-run with -Direct." }
        Write-Host "ADF run: $runId"
        $status = ''
        for ($i = 0; $i -lt 60; $i++) {
            Start-Sleep -Seconds 6
            $status = az datafactory pipeline-run show --factory-name $names.Factory --resource-group $names.ResourceGroup --run-id $runId --query status -o tsv
            Write-Host "  status: $status"
            if ($status -in 'Succeeded', 'Failed', 'Cancelled') { break }
        }
        if ($status -ne 'Succeeded') { throw "ADF run ended with status '$status'. If the managed private endpoint is not approved, re-run with -Direct." }
    }
    & $sql -Query "SELECT (SELECT COUNT(*) FROM core.Impact WHERE RunId=(SELECT RunId FROM core.Published)) Impacts, (SELECT COUNT(*) FROM core.Evidence WHERE RunId=(SELECT RunId FROM core.Published)) Evidence, (SELECT COUNT(*) FROM casework.ReviewCase) Cases, (SELECT SUM(AffectedEmployees) FROM core.Impact WHERE RunId=(SELECT RunId FROM core.Published)) AffectedEmployees;" | Out-Host
}
