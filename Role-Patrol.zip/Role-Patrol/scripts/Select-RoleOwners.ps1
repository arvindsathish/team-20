<#
.SYNOPSIS
    Selects the two demo role owners (Owner A = US, Owner B = Canada) from the dataset and records them in names.json.
.DESCRIPTION
    Nothing is hard-coded. For each country the role with the most post-transfer friction tickets
    (Request_Type = 'Missing Role Access' and Present_In_Role_At_Request = 'N') is chosen, and its
    Role_Owner_GID becomes the portal lead. Ties are broken by the lowest Business_Role_ID.
    The owner must be an Active employee. Re-run after the dataset changes, then regenerate the
    Entra directory (Step A1), SQL permissions (Step C4) and the web bundle (Step D5).
#>
[CmdletBinding()]
param(
    [string]$DatasetDir = "..\datasets",
    [string]$NamesFile  = "..\names.json",
    [string]$CountryA   = "GM Financial US",
    [string]$CountryB   = "GM Financial Canada"
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
function Resolve-Existing([string]$Path) {
    foreach ($c in @($Path, (Join-Path $PWD $Path), (Join-Path $scriptDir $Path))) {
        if ($c -and (Test-Path -LiteralPath $c)) { return (Resolve-Path -LiteralPath $c).Path }
    }
    throw "Path not found: $Path"
}

$datasets  = Resolve-Existing $DatasetDir
$namesPath = Resolve-Existing $NamesFile

$roles   = Import-Csv (Join-Path $datasets "BUSINESS_ROLE_MASTER.csv")
$ticketCsv = @("ACCESS_REQUEST_TICKETS.csv", "MOCK_ACCESS_TICKETS.csv") | ForEach-Object { Join-Path $datasets $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $ticketCsv) { throw "No tickets CSV (ACCESS_REQUEST_TICKETS.csv or MOCK_ACCESS_TICKETS.csv) in $datasets" }
$tickets = Import-Csv $ticketCsv
$emps    = Import-Csv (Join-Path $datasets "EMPLOYEE_IDENTITY.csv")
$empById = @{}
foreach ($e in $emps) { $empById[$e.GID] = $e }

$friction = @{}
foreach ($t in $tickets) {
    if ($t.Request_Type -eq 'Missing Role Access' -and $t.Present_In_Role_At_Request -eq 'N') {
        $friction[$t.Business_Role_ID] = 1 + [int]$friction[$t.Business_Role_ID]
    }
}

function Select-Owner([string]$Country) {
    $pick = $roles |
        Where-Object { $_.Business_Group -eq $Country -and $_.Active_Status -eq 'Active' -and $empById[$_.Role_Owner_GID].'Active Status' -eq 'Active' } |
        Sort-Object @{ Expression = { -[int]$friction[$_.Business_Role_ID] } }, Business_Role_ID |
        Select-Object -First 3
    if (-not $pick) { throw "No eligible role owner found for $Country" }
    Write-Host "Top candidate roles for ${Country}:" -ForegroundColor Cyan
    $pick | ForEach-Object { Write-Host ("  {0}  tickets={1}  owner={2}" -f $_.Business_Role_ID, [int]$friction[$_.Business_Role_ID], $_.Role_Owner_GID) }
    $role = $pick | Select-Object -First 1
    $emp  = $empById[$role.Role_Owner_GID]
    [pscustomobject]@{
        Gid      = $role.Role_Owner_GID
        Name     = "$($emp.'First Name') $($emp.'Last Name')"
        RoleId   = $role.Business_Role_ID
        RoleName = $role.Business_Role_Name
        Tickets  = [int]$friction[$role.Business_Role_ID]
        Country  = $Country
    }
}

$a = Select-Owner $CountryA
$b = Select-Owner $CountryB
if ($a.Gid -eq $b.Gid) { throw "Owner A and Owner B resolved to the same employee ($($a.Gid))." }

$names = Get-Content -LiteralPath $namesPath -Raw | ConvertFrom-Json
$values = [ordered]@{
    OwnerAGid      = $a.Gid;  OwnerAName     = $a.Name;  OwnerARoleId = $a.RoleId;  OwnerARoleName = $a.RoleName;  OwnerACountry = $a.Country
    OwnerBGid      = $b.Gid;  OwnerBName     = $b.Name;  OwnerBRoleId = $b.RoleId;  OwnerBRoleName = $b.RoleName;  OwnerBCountry = $b.Country
}
foreach ($k in $values.Keys) { $names | Add-Member -NotePropertyName $k -NotePropertyValue $values[$k] -Force }
[IO.File]::WriteAllText($namesPath, ($names | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))

Write-Host ("Owner A ({0}): {1} {2} - role {3} ({4} friction tickets)" -f $a.Country, $a.Gid, $a.Name, $a.RoleId, $a.Tickets) -ForegroundColor Green
Write-Host ("Owner B ({0}): {1} {2} - role {3} ({4} friction tickets)" -f $b.Country, $b.Gid, $b.Name, $b.RoleId, $b.Tickets) -ForegroundColor Green
Write-Host "Saved to $namesPath" -ForegroundColor Green
