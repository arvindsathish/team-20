<#
.SYNOPSIS
    Zip-deploys the built portal (web\dist) to the private portal Web App (replaces Deploy-Swa.ps1).
.DESCRIPTION
    Requires web\dist\index.html, bridge.html, and logo.png produced by web\Build-Html.ps1 for THIS lab (the checked-in build of the original
    tenant was removed). Run from the lab network: the Web App's SCM endpoint is private.
#>
[CmdletBinding()]
param([string]$NamesFile = "..\names.json")

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$root = Split-Path -Parent $scriptDir
$namesPath = @($NamesFile, (Join-Path $scriptDir $NamesFile), (Join-Path $PWD "names.json")) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
if (-not $namesPath) { throw "names.json not found." }
$names = Get-Content -LiteralPath $namesPath -Raw | ConvertFrom-Json

$dist = Join-Path $root 'web\dist'
foreach ($f in 'index.html', 'bridge.html', 'logo.png') {
    if (-not (Test-Path -LiteralPath (Join-Path $dist $f))) { throw "web\dist\$f not found - run web\Build-Catalog.ps1, web\Build-App.ps1 and web\Build-Html.ps1 first (Step D5)." }
}
$html = [IO.File]::ReadAllText((Join-Path $dist 'index.html'))
if (-not $html.Contains($names.SpaClientId) -or -not $html.Contains($names.TenantId)) {
    throw "web\dist\index.html was not built with this lab's tenant/SPA client ID. Re-run Step D5 after Step D4 (web\config.json)."
}

$zip = Join-Path ([IO.Path]::GetTempPath()) "rp-web-dist.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $dist 'index.html'), (Join-Path $dist 'bridge.html'), (Join-Path $dist 'logo.png') -DestinationPath $zip -Force

az webapp deploy -g $names.AppResourceGroup -n $names.WebApp --src-path $zip --type zip
if ($LASTEXITCODE -ne 0) { throw "Zip deploy failed for $($names.WebApp)." }
Remove-Item $zip -Force
Write-Host "Portal deployed: $($names.WebUrl)" -ForegroundColor Green
