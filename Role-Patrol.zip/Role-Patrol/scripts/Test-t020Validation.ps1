<#
.SYNOPSIS
    Automated validation suite for the Role Patrol lab deployment.
.DESCRIPTION
    Every expectation is derived from names.json and the CSVs in .\datasets - no counts, owners or role IDs are hard-coded.
    Run from a lab-network machine after Step 5.1 (SQL, Search and the Web Apps are private-only).
#>
[CmdletBinding()]
param(
    [string]$NamesFile = "..\names.json",
    [switch]$SingleOwnerDemo
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$root = Split-Path -Parent $scriptDir
$namesPath = @($NamesFile, (Join-Path $scriptDir $NamesFile), (Join-Path $PWD "names.json")) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $namesPath) { throw "names.json not found." }
$names = Get-Content -LiteralPath $namesPath -Raw | ConvertFrom-Json
$datasets = Join-Path $root 'datasets'
$sqlRunner = Join-Path $scriptDir 'Invoke-RpSql.ps1'

$passCount = 0; $failCount = 0
function Assert-Check {
    param([Parameter(Mandatory)][string]$Description, [Parameter(Mandatory)][bool]$Condition)
    if ($Condition) { Write-Host "  [PASS] $Description" -ForegroundColor Green; $script:passCount++ }
    else { Write-Host "  [FAIL] $Description" -ForegroundColor Red; $script:failCount++ }
}
function Get-Count([string]$File) { @(Import-Csv (Join-Path $datasets $File)).Count }
function Invoke-Safe([scriptblock]$Block) { try { & $Block } catch { Write-Warning $_.Exception.Message; $null } }

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " Role Patrol - Automated Validation Suite" -ForegroundColor Cyan
Write-Host " SQL: $($names.SqlServer)/$($names.Database)  Web: $($names.WebUrl)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 1. Configuration sanity
Write-Host "`n>>> Check 1: names.json matches the signed-in subscription" -ForegroundColor Yellow
$acct = az account show -o json | ConvertFrom-Json
Assert-Check "names.json SubscriptionId equals the active subscription ($($acct.id))" ($names.SubscriptionId -eq $acct.id)
Assert-Check "names.json TenantId equals the active tenant" ($names.TenantId -eq $acct.tenantId)
foreach ($k in 'SqlServer','Database','SearchService','Factory','WebApp','ApiA','ApiB','OwnerAGid','OwnerBGid','ApiClientId','SpaClientId','WebUrl') {
    Assert-Check "names.json has $k" (-not [string]::IsNullOrWhiteSpace($names.$k))
}

# 2. Azure resources
Write-Host "`n>>> Check 2: Azure resources (committee + created)" -ForegroundColor Yellow
$sqlState = Invoke-Safe { az sql db show -g $names.SqlResourceGroup -s $names.SqlServer -n $names.Database --query status -o tsv }
Assert-Check "SQL database $($names.Database) is Online" ($sqlState -eq 'Online')
$sqlPna = Invoke-Safe { az sql server show -g $names.SqlResourceGroup -n $names.SqlServer --query publicNetworkAccess -o tsv }
Assert-Check "SQL public network access is Disabled (private-only lab)" ($sqlPna -eq 'Disabled')
$srch = Invoke-Safe { az search service show -g $names.SearchResourceGroup -n $names.SearchService --query name -o tsv }
Assert-Check "AI Search service $($names.SearchService) exists" ($srch -eq $names.SearchService)
foreach ($app in $names.WebApp, $names.ApiA, $names.ApiB) {
    $st = Invoke-Safe { az webapp show -g $names.AppResourceGroup -n $app --query state -o tsv }
    Assert-Check "Web App $app is Running" ($st -eq 'Running')
    $mi = Invoke-Safe { az webapp identity show -g $names.AppResourceGroup -n $app --query principalId -o tsv }
    Assert-Check "Web App $app has a system-assigned managed identity" (-not [string]::IsNullOrWhiteSpace($mi))
}
if ($SingleOwnerDemo) {
    Write-Host "  [SKIP] ADF pipeline check (single-owner demo uses direct SQL assessment)." -ForegroundColor DarkYellow
} else {
    $pip = Invoke-Safe { az datafactory pipeline list -g $names.ResourceGroup --factory-name $names.Factory --query "[?name=='RolePatrolAssessment'].name" -o tsv }
    Assert-Check "ADF pipeline RolePatrolAssessment is deployed in $($names.Factory)" ($pip -eq 'RolePatrolAssessment')
}

# 3. Portal reachability (private endpoint)
Write-Host "`n>>> Check 3: Portal and MSAL bridge" -ForegroundColor Yellow
foreach ($u in "$($names.WebUrl)/", "$($names.WebUrl)/bridge.html") {
    $code = Invoke-Safe { (Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 20).StatusCode }
    Assert-Check "$u returns HTTP 200" ($code -eq 200)
}
$html = Invoke-Safe { (Invoke-WebRequest -Uri "$($names.WebUrl)/" -UseBasicParsing -TimeoutSec 20).Content }
Assert-Check "Deployed index.html carries this tenant/SPA client ID (not a stale build)" ($html -and $html.Contains($names.SpaClientId) -and $html.Contains($names.TenantId))

# 4. SQL row counts vs the CSVs
Write-Host "`n>>> Check 4: Azure SQL contents equal the dataset" -ForegroundColor Yellow
function Get-SqlValue([string]$Query) { $r = Invoke-Safe { & $sqlRunner -Query $Query -NamesFile $namesPath }; if ($r) { @($r)[0][0] } else { $null } }
$expect = [ordered]@{
    'src.Employee'  = (Get-Count 'EMPLOYEE_IDENTITY.csv')
    'src.Entitlement' = (Get-Count 'ENTITLEMENT_CATALOG.csv')
    'src.Application' = (Get-Count 'APPLICATION_MASTER.csv')
    'src.Move'      = (Get-Count 'JML_EVENTS.csv')
    'src.Ticket'    = $(if (Test-Path (Join-Path $datasets 'ACCESS_REQUEST_TICKETS.csv')) { Get-Count 'ACCESS_REQUEST_TICKETS.csv' } else { Get-Count 'MOCK_ACCESS_TICKETS.csv' })
}
foreach ($t in $expect.Keys) {
    $n = Get-SqlValue "SELECT COUNT(*) FROM $t;"
    Assert-Check "$t has $($expect[$t]) rows (actual: $n)" ($n -eq $expect[$t])
}
$roleCsv = Get-Count 'BUSINESS_ROLE_MASTER.csv'
$n = Get-SqlValue "SELECT COUNT(*) FROM src.Role WHERE RoleId LIKE 'BR%';"
Assert-Check "src.Role has $roleCsv business roles (actual: $n)" ($n -eq $roleCsv)
$published = Get-SqlValue "SELECT COUNT(*) FROM core.Published;"
Assert-Check "An assessment run is published (core.Published rows: $published)" ($published -ge 1)

# 5. Owners and permissions (from names.json + the dataset)
Write-Host "`n>>> Check 5: Role-owner governance mapping" -ForegroundColor Yellow
$roles = Import-Csv (Join-Path $datasets 'BUSINESS_ROLE_MASTER.csv')
foreach ($o in @(@{ T='A'; G=$names.OwnerAGid; R=$names.OwnerARoleId; A=$names.ApiA }, @{ T='B'; G=$names.OwnerBGid; R=$names.OwnerBRoleId; A=$names.ApiB })) {
    $csvOwner = ($roles | Where-Object Business_Role_ID -eq $o.R).Role_Owner_GID
    Assert-Check "Dataset: $($o.R) is owned by $($o.G) (Owner $($o.T))" ($csvOwner -eq $o.G)
    $dbOwner = Get-SqlValue "SELECT OwnerEmployeeId FROM src.Role WHERE RoleId = '$($o.R)';"
    Assert-Check "SQL: src.Role $($o.R) owner = $($o.G) (actual: $dbOwner)" ($dbOwner -eq $o.G)
    $map = Get-SqlValue "SELECT EmployeeId FROM core.Principal WHERE DbUser = '$($o.A)';"
    Assert-Check "SQL: core.Principal maps $($o.A) to $($o.G) (actual: $map)" ($map -eq $o.G)
    $dec = Get-SqlValue "SELECT COUNT(*) FROM core.Permission WHERE EmployeeId = '$($o.G)' AND RoleId = '$($o.R)' AND CanDecide = 1;"
    Assert-Check "SQL: $($o.G) can decide on $($o.R)" ($dec -eq 1)
}

# 6. Search index
Write-Host "`n>>> Check 6: AI Search index ticket-text" -ForegroundColor Yellow
$st = az account get-access-token --resource "https://search.azure.com" --query accessToken -o tsv
$docCount = Invoke-Safe { Invoke-RestMethod -Uri "https://$($names.SearchService).search.windows.net/indexes/ticket-text/docs/`$count?api-version=2024-07-01" -Headers @{ Authorization = "Bearer $st" } }
Assert-Check "ticket-text contains $($expect['src.Ticket']) documents (actual: $docCount)" ([int]$docCount -eq $expect['src.Ticket'])

# 7. Gateways reject anonymous callers
Write-Host "`n>>> Check 7: API gateways require an Entra token" -ForegroundColor Yellow
$gatewayApps = if ($SingleOwnerDemo) { @($names.ApiA) } else { @($names.ApiA, $names.ApiB) }
foreach ($app in $gatewayApps) {
    $code = Invoke-Safe {
        try { (Invoke-WebRequest -Uri "https://$app.azurewebsites.net/api/gateway" -Method Post -Body '{"op":"overview"}' -ContentType 'application/json' -UseBasicParsing -TimeoutSec 20).StatusCode }
        catch { [int]$_.Exception.Response.StatusCode }
    }
    Assert-Check "https://$app.azurewebsites.net/api/gateway returns 401 without a token (actual: $code)" ($code -eq 401)
}

$color = if ($failCount -eq 0) { "Green" } else { "Red" }
Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host " Validation Complete: $passCount Passed, $failCount Failed" -ForegroundColor $color
Write-Host "==========================================================" -ForegroundColor Cyan
if ($failCount -gt 0) { exit 1 }
