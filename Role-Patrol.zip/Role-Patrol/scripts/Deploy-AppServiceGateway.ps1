<#
.SYNOPSIS
    Deploys the OAuth-protected API gateway(s) (Role Patrol) and writes web\config.json.
.DESCRIPTION
    Replaces Deploy-LogicAppGateway.ps1 (Consumption Logic Apps cannot reach the private-only SQL / AI Search endpoints).
    By default, deploys ApiA (Owner A) and ApiB (Owner B). With -SingleOwnerDemo, deploys only ApiA for Owner A:
      - sets App Settings (tenant, API/SPA client IDs, owner object ID, SQL, Search, allowed web origin, pre-fetched Entra signing keys)
      - zip-deploys .\gateway (server.js + package.json; node_modules when present, otherwise the App Service builds them)
      - verifies GET /healthz through the private endpoint
    Then writes web\config.json (consumed by web\Build-Html.ps1) and the gateway URLs into names.json.
    Prerequisites: Steps A2-A3 (ApiClientId/SpaClientId), C2-C4 (web apps, SQL users), D2 (WebUrl), and an approved identity-map.csv.
    The single-owner demo map contains only Owner A and does not require the bulk A1 directory import.
#>
[CmdletBinding()]
param(
    [string]$NamesFile = "..\names.json",
    [switch]$SingleOwnerDemo
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$root = Split-Path -Parent $scriptDir
$namesPath = @($NamesFile, (Join-Path $scriptDir $NamesFile), (Join-Path $PWD "names.json")) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
if (-not $namesPath) { throw "names.json not found." }
$names = Get-Content -LiteralPath $namesPath -Raw | ConvertFrom-Json

foreach ($k in 'TenantId','ApiClientId','SpaClientId','WebUrl','AppResourceGroup','ApiA','ApiB','OwnerAGid','OwnerBGid','SqlServer','Database','SearchService') {
    if ([string]::IsNullOrWhiteSpace($names.$k)) { throw "names.json is missing '$k'. Complete Steps 0.2, A1-A3 and D2 first." }
}
$idMapPath = Join-Path $root 'directory-output\identity-map.csv'
if (-not (Test-Path -LiteralPath $idMapPath)) { throw "directory-output\identity-map.csv not found - create the approved owner mapping in Step C4 or run Step A1." }
$idMap = Import-Csv $idMapPath
$oidA = ($idMap | Where-Object EmployeeId -eq $names.OwnerAGid | Select-Object -First 1).ObjectId
if (-not $oidA) { throw "Owner A object ID for $($names.OwnerAGid) is missing from identity-map.csv." }
$oidA = ([guid]$oidA).ToString()
$oidB = $null
if (-not $SingleOwnerDemo) {
    $oidB = ($idMap | Where-Object EmployeeId -eq $names.OwnerBGid | Select-Object -First 1).ObjectId
    if (-not $oidB) { throw "Owner B object ID for $($names.OwnerBGid) is missing from identity-map.csv. Use -SingleOwnerDemo for an approved one-owner demo." }
    $oidB = ([guid]$oidB).ToString()
    if ($oidA -eq $oidB) { throw "Owner A and Owner B must have distinct Entra object IDs. Use -SingleOwnerDemo for one approved account." }
}

# Entra signing keys, fetched here so the gateway still works if the App Service cannot reach login.microsoftonline.com
$jwksJson = (Invoke-RestMethod -Uri "https://login.microsoftonline.com/$($names.TenantId)/discovery/v2.0/keys" -TimeoutSec 30) | ConvertTo-Json -Depth 8 -Compress

# Stage the package
$gatewayDir = Join-Path $root 'gateway'
$hasModules = Test-Path -LiteralPath (Join-Path $gatewayDir 'node_modules\tedious')
$stage = Join-Path ([IO.Path]::GetTempPath()) ("rp-gateway-" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage | Out-Null
Copy-Item (Join-Path $gatewayDir 'server.js'), (Join-Path $gatewayDir 'package.json') -Destination $stage
if ($hasModules) { Copy-Item (Join-Path $gatewayDir 'node_modules') -Destination $stage -Recurse }
$zip = Join-Path ([IO.Path]::GetTempPath()) "rp-gateway.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -Force
Write-Host ("Gateway package: {0:N0} KB (node_modules bundled: {1})" -f ((Get-Item $zip).Length / 1KB), $hasModules) -ForegroundColor Cyan

$gateways = @(
    @{ App = $names.ApiA; Oid = $oidA; Gid = $names.OwnerAGid; Key = 'ApiAUrl' }
)
if (-not $SingleOwnerDemo) {
    $gateways += @{ App = $names.ApiB; Oid = $oidB; Gid = $names.OwnerBGid; Key = 'ApiBUrl' }
}
$urls = @{}
foreach ($g in $gateways) {
    Write-Host "`n>>> Deploying gateway $($g.App) (owner $($g.Gid))" -ForegroundColor Yellow
    $settings = @(
        @{ name = 'TENANT_ID';     value = $names.TenantId },
        @{ name = 'API_CLIENT_ID'; value = $names.ApiClientId },
        @{ name = 'SPA_CLIENT_ID'; value = $names.SpaClientId },
        @{ name = 'OWNER_OID';     value = $g.Oid },
        @{ name = 'SQL_SERVER';    value = $names.SqlServer },
        @{ name = 'SQL_DATABASE';  value = $names.Database },
        @{ name = 'SEARCH_SERVICE';value = $names.SearchService },
        @{ name = 'WEB_ORIGIN';    value = $names.WebUrl.TrimEnd('/') },
        @{ name = 'ENTRA_JWKS';    value = $jwksJson },
        @{ name = 'SCM_DO_BUILD_DURING_DEPLOYMENT'; value = $(if ($hasModules) { 'false' } else { 'true' }) }
    ) | ForEach-Object { $_['slotSetting'] = $false; [pscustomobject]$_ }
    $settingsFile = Join-Path ([IO.Path]::GetTempPath()) ("rp-settings-" + [guid]::NewGuid().ToString('N') + ".json")
    [IO.File]::WriteAllText($settingsFile, ($settings | ConvertTo-Json -Depth 4), [Text.UTF8Encoding]::new($false))
    az webapp config appsettings set -g $names.AppResourceGroup -n $g.App --settings "@$settingsFile" | Out-Null
    Remove-Item $settingsFile -Force
    if ($LASTEXITCODE -ne 0) { throw "Failed to set app settings on $($g.App)" }

    az webapp config set -g $names.AppResourceGroup -n $g.App --startup-file "node server.js" | Out-Null
    az webapp deploy -g $names.AppResourceGroup -n $g.App --src-path $zip --type zip | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Zip deploy failed for $($g.App) (run from the lab network; SCM is private)." }

    $base = "https://$((az webapp show -g $names.AppResourceGroup -n $g.App --query defaultHostName -o tsv))"
    $urls[$g.Key] = "$base/api/gateway"
    $ok = $false
    for ($i = 1; $i -le 12 -and -not $ok; $i++) {
        try { $ok = ((Invoke-WebRequest -Uri "$base/healthz" -UseBasicParsing -TimeoutSec 15).StatusCode -eq 200) } catch { Start-Sleep -Seconds 10 }
    }
    if ($ok) { Write-Host "  healthz OK: $base/healthz" -ForegroundColor Green } else { Write-Warning "  healthz did not answer yet at $base/healthz (check the app log stream)." }
}
Remove-Item $stage -Recurse -Force; Remove-Item $zip -Force

# web\config.json (inlined into the portal by web\Build-Html.ps1)
$config = [ordered]@{
    tenantId      = $names.TenantId
    clientId      = $names.SpaClientId
    apiClientId   = $names.ApiClientId
    redirectUri   = "$($names.WebUrl.TrimEnd('/'))/bridge.html"
    apiByObjectId = [ordered]@{ $oidA = $urls['ApiAUrl'] }
}
if (-not $SingleOwnerDemo) { $config.apiByObjectId[$oidB] = $urls['ApiBUrl'] }
[IO.File]::WriteAllText((Join-Path $root 'web\config.json'), ($config | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))

$nameUpdates = @{ ApiAUrl = $urls['ApiAUrl']; OwnerAObjectId = $oidA }
if (-not $SingleOwnerDemo) {
    $nameUpdates.ApiBUrl = $urls['ApiBUrl']
    $nameUpdates.OwnerBObjectId = $oidB
}
foreach ($kv in $nameUpdates.GetEnumerator()) {
    $names | Add-Member -NotePropertyName $kv.Key -NotePropertyValue $kv.Value -Force
}
[IO.File]::WriteAllText($namesPath, ($names | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
if ($SingleOwnerDemo) {
    Write-Host "`nSingle-owner demo gateway deployed for Owner A. Authentication remains enabled; this account maps only to the synthetic Owner A record." -ForegroundColor Yellow
    Write-Host "Wrote web\config.json and updated names.json (ApiAUrl, OwnerAObjectId)." -ForegroundColor Green
} else {
    Write-Host "`nWrote web\config.json and updated names.json (ApiAUrl, ApiBUrl, OwnerAObjectId, OwnerBObjectId)." -ForegroundColor Green
}
