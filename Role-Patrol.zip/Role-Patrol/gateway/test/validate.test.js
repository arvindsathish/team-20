'use strict';
// Offline tests for the gateway's Entra token policy (no network, no SQL). Run: node --test
const test = require('node:test');
const assert = require('node:assert');
const crypto = require('crypto');
const http = require('http');

const TENANT = '11111111-1111-1111-1111-111111111111';
const API = '22222222-2222-2222-2222-222222222222';
const SPA = '33333333-3333-3333-3333-333333333333';
const OWNER = '44444444-4444-4444-4444-444444444444';

const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = Object.assign(publicKey.export({ format: 'jwk' }), { kid: 'test-key', use: 'sig', alg: 'RS256' });

process.env.TENANT_ID = TENANT;
process.env.API_CLIENT_ID = API;
process.env.SPA_CLIENT_ID = SPA;
process.env.OWNER_OID = OWNER;
process.env.SQL_SERVER = 'sql.invalid';
process.env.SQL_DATABASE = 'db';
process.env.SEARCH_SERVICE = 'search.invalid';
process.env.WEB_ORIGIN = 'https://web.invalid';
process.env.ENTRA_JWKS = JSON.stringify({ keys: [jwk] });
process.env.JWKS_STATIC_ONLY = 'true';
const { validateToken, server } = require('../server.js');

const b64 = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
function makeToken(over = {}, headerOver = {}) {
  const now = Math.floor(Date.now() / 1000);
  const claims = Object.assign({
    iss: `https://login.microsoftonline.com/${TENANT}/v2.0`, tid: TENANT, aud: API, azp: SPA, scp: 'RolePatrol.Access',
    oid: OWNER, nbf: now - 10, exp: now + 3600
  }, over);
  const header = Object.assign({ alg: 'RS256', typ: 'JWT', kid: 'test-key' }, headerOver);
  const signingInput = `${b64(header)}.${b64(claims)}`;
  const sig = crypto.createSign('RSA-SHA256').update(signingInput).sign(privateKey).toString('base64url');
  return `Bearer ${signingInput}.${sig}`;
}

test('accepts a valid owner token', async () => {
  const r = await validateToken(makeToken());
  assert.strictEqual(r.ok, true);
});
test('rejects missing and malformed tokens', async () => {
  assert.strictEqual((await validateToken(undefined)).status, 401);
  assert.strictEqual((await validateToken('Bearer a.b')).status, 401);
});
test('rejects a token for a different owner (oid)', async () => {
  const r = await validateToken(makeToken({ oid: '99999999-9999-9999-9999-999999999999' }));
  assert.strictEqual(r.ok, false); assert.strictEqual(r.status, 403);
});
test('rejects wrong audience, issuer, tenant, azp and scope', async () => {
  assert.strictEqual((await validateToken(makeToken({ aud: SPA }))).status, 401);
  assert.strictEqual((await validateToken(makeToken({ iss: 'https://sts.windows.net/x/' }))).status, 401);
  assert.strictEqual((await validateToken(makeToken({ tid: OWNER }))).status, 401);
  assert.strictEqual((await validateToken(makeToken({ azp: OWNER }))).status, 403);
  assert.strictEqual((await validateToken(makeToken({ scp: 'User.Read' }))).status, 403);
});
test('rejects expired tokens and tampered signatures', async () => {
  const past = Math.floor(Date.now() / 1000) - 7200;
  assert.strictEqual((await validateToken(makeToken({ exp: past, nbf: past - 100 }))).status, 401);
  const good = makeToken();
  const tampered = good.slice(0, -4) + (good.endsWith('AAAA') ? 'BBBB' : 'AAAA');
  assert.strictEqual((await validateToken(tampered)).status, 401);
});
test('rejects alg=none and unknown kid', async () => {
  assert.strictEqual((await validateToken(makeToken({}, { alg: 'none' }))).status, 401);
  assert.strictEqual((await validateToken(makeToken({}, { kid: 'other' }))).status, 401);
});

test('HTTP: healthz is open, gateway requires a token, CORS preflight answers', async () => {
  await new Promise((resolve) => server.listen(0, resolve));
  const port = server.address().port;
  const call = (method, path, headers = {}, body) => new Promise((resolve, reject) => {
    const req = http.request({ method, port, path, headers }, (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: d })); });
    req.on('error', reject); if (body) req.write(body); req.end();
  });
  assert.strictEqual((await call('GET', '/healthz')).status, 200);
  const anon = await call('POST', '/api/gateway', { 'Content-Type': 'application/json' }, '{"op":"overview"}');
  assert.strictEqual(anon.status, 401);
  const pre = await call('OPTIONS', '/api/gateway');
  assert.strictEqual(pre.status, 204);
  assert.strictEqual(pre.headers['access-control-allow-origin'], 'https://web.invalid');
  assert.strictEqual((await call('GET', '/nope')).status, 404);
  const badOwner = await call('POST', '/api/gateway', { Authorization: makeToken({ oid: '99999999-9999-9999-9999-999999999999' }), 'Content-Type': 'application/json' }, '{"op":"overview"}');
  assert.strictEqual(badOwner.status, 403);
  server.close();
});
