'use strict';
/*
 * Role Patrol API gateway (replaces the Consumption Logic Apps of the original design, which cannot reach the
 * private-only SQL server and AI Search service in the lab).
 *
 * POST /api/gateway   Authorization: Bearer <Entra v2 access token for api://<ApiClientId>/RolePatrol.Access>
 *   1. Validates the token (iss / aud / tid / azp / scp / oid == this gateway's owner) - same policy as the Logic App.
 *   2. op = ticketSearch (and searchAction != refresh): semantic Azure AI Search query (managed identity), lexical fallback,
 *      then api.usp_Gateway with { ...body, searchResponse, searchMode }; 503 when search is unavailable.
 *   3. Every other op: api.usp_Gateway with the request body as @Payload.
 *   Response: first row of the procedure's result set -> HTTP status (HttpStatus) + JSON body (ResponseJson).
 * GET /healthz        Unauthenticated liveness probe.
 *
 * Configuration (App Settings): TENANT_ID, API_CLIENT_ID, SPA_CLIENT_ID, OWNER_OID, SQL_SERVER, SQL_DATABASE,
 * SEARCH_SERVICE, WEB_ORIGIN, ENTRA_JWKS (optional pre-fetched JWKS JSON for networks that cannot reach login.microsoftonline.com),
 * JWKS_STATIC_ONLY=true (use only ENTRA_JWKS; for offline tests).
 */
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const cfg = {
  tenantId: process.env.TENANT_ID,
  apiClientId: process.env.API_CLIENT_ID,
  spaClientId: process.env.SPA_CLIENT_ID,
  ownerOid: (process.env.OWNER_OID || '').toLowerCase(),
  sqlServer: process.env.SQL_SERVER,
  sqlDatabase: process.env.SQL_DATABASE,
  searchService: process.env.SEARCH_SERVICE,
  webOrigin: (process.env.WEB_ORIGIN || '').replace(/\/+$/, ''),
  staticJwks: process.env.ENTRA_JWKS || '',
  jwksStaticOnly: process.env.JWKS_STATIC_ONLY === 'true',
  port: process.env.PORT || 8080
};
const REQUIRED_SCOPE = 'RolePatrol.Access';
const MAX_BODY = 64 * 1024;

// ---------- helpers ----------
function b64urlToBuf(s) { return Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64'); }

function responseHeaders(extra) {
  return Object.assign({
    'Access-Control-Allow-Origin': cfg.webOrigin,
    'Cache-Control': 'no-store',
    'Content-Type': 'application/json',
    'Referrer-Policy': 'no-referrer',
    'Vary': 'Origin',
    'X-Content-Type-Options': 'nosniff'
  }, extra || {});
}
function send(res, status, body) {
  res.writeHead(status, responseHeaders());
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function httpsJson(method, urlString, headers, bodyObj, timeoutMs) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlString);
    const payload = bodyObj ? JSON.stringify(bodyObj) : null;
    const req = https.request({
      method, hostname: u.hostname, port: u.port || 443, path: u.pathname + u.search,
      headers: Object.assign({}, headers, payload ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } : {}),
      timeout: timeoutMs || 15000
    }, (r) => {
      const chunks = [];
      r.on('data', (c) => chunks.push(c));
      r.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let json = null; try { json = text ? JSON.parse(text) : null; } catch { /* non-JSON */ }
        resolve({ status: r.statusCode, json, text });
      });
    });
    req.on('timeout', () => req.destroy(new Error('request timed out')));
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ---------- managed identity tokens (App Service) ----------
const tokenCache = new Map();
function getMsiToken(resource) {
  const cached = tokenCache.get(resource);
  if (cached && cached.expiresOn - 120 > Date.now() / 1000) return Promise.resolve(cached.token);
  const endpoint = process.env.IDENTITY_ENDPOINT;
  const header = process.env.IDENTITY_HEADER;
  if (!endpoint || !header) return Promise.reject(new Error('Managed identity endpoint is not available'));
  return new Promise((resolve, reject) => {
    const u = new URL(endpoint);
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request({
      method: 'GET', hostname: u.hostname, port: u.port, path: `${u.pathname}?resource=${encodeURIComponent(resource)}&api-version=2019-08-01`,
      headers: { 'X-IDENTITY-HEADER': header }, timeout: 10000
    }, (r) => {
      const chunks = [];
      r.on('data', (c) => chunks.push(c));
      r.on('end', () => {
        try {
          const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          if (!j.access_token) throw new Error(j.error_description || j.message || 'no access_token');
          tokenCache.set(resource, { token: j.access_token, expiresOn: Number(j.expires_on) });
          resolve(j.access_token);
        } catch (e) { reject(new Error(`Managed identity token request failed: ${e.message}`)); }
      });
    });
    req.on('timeout', () => req.destroy(new Error('managed identity request timed out')));
    req.on('error', reject);
    req.end();
  });
}

// ---------- Entra token validation ----------
let jwksCache = { keys: null, fetchedAt: 0 };
async function getJwks(force) {
  if (cfg.jwksStaticOnly && cfg.staticJwks) {
    const parsed = JSON.parse(cfg.staticJwks);
    return parsed.keys || parsed;
  }
  const fresh = jwksCache.keys && (Date.now() - jwksCache.fetchedAt < 6 * 3600 * 1000);
  if (fresh && !force) return jwksCache.keys;
  try {
    const r = await httpsJson('GET', `https://login.microsoftonline.com/${cfg.tenantId}/discovery/v2.0/keys`, {}, null, 8000);
    if (r.status === 200 && r.json && Array.isArray(r.json.keys)) {
      jwksCache = { keys: r.json.keys, fetchedAt: Date.now() };
      return jwksCache.keys;
    }
  } catch (e) { console.warn('JWKS refresh failed:', e.message); }
  if (jwksCache.keys) return jwksCache.keys;
  if (cfg.staticJwks) {
    try { const parsed = JSON.parse(cfg.staticJwks); const keys = parsed.keys || parsed; jwksCache = { keys, fetchedAt: Date.now() - 5 * 3600 * 1000 }; return keys; }
    catch (e) { console.error('ENTRA_JWKS is not valid JSON:', e.message); }
  }
  throw new Error('No signing keys available to validate the token');
}

async function validateToken(authHeader) {
  const m = /^Bearer\s+(.+)$/i.exec(authHeader || '');
  if (!m) return { ok: false, status: 401, error: 'Missing bearer token' };
  const parts = m[1].split('.');
  if (parts.length !== 3) return { ok: false, status: 401, error: 'Malformed token' };
  let header, claims;
  try { header = JSON.parse(b64urlToBuf(parts[0]).toString('utf8')); claims = JSON.parse(b64urlToBuf(parts[1]).toString('utf8')); }
  catch { return { ok: false, status: 401, error: 'Malformed token' }; }
  if (header.alg !== 'RS256' || !header.kid) return { ok: false, status: 401, error: 'Unsupported token algorithm' };

  let keys = await getJwks(false);
  let jwk = keys.find((k) => k.kid === header.kid);
  if (!jwk) { keys = await getJwks(true); jwk = keys.find((k) => k.kid === header.kid); }
  if (!jwk) return { ok: false, status: 401, error: 'Unknown signing key' };

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(`${parts[0]}.${parts[1]}`);
  const valid = verifier.verify(crypto.createPublicKey({ key: jwk, format: 'jwk' }), b64urlToBuf(parts[2]));
  if (!valid) return { ok: false, status: 401, error: 'Invalid token signature' };

  const now = Math.floor(Date.now() / 1000);
  if (typeof claims.exp !== 'number' || claims.exp + 60 < now) return { ok: false, status: 401, error: 'Token expired' };
  if (typeof claims.nbf === 'number' && claims.nbf - 60 > now) return { ok: false, status: 401, error: 'Token not yet valid' };
  if (claims.iss !== `https://login.microsoftonline.com/${cfg.tenantId}/v2.0`) return { ok: false, status: 401, error: 'Wrong issuer' };
  if (claims.tid !== cfg.tenantId) return { ok: false, status: 401, error: 'Wrong tenant' };
  if (claims.aud !== cfg.apiClientId) return { ok: false, status: 401, error: 'Wrong audience' };
  if (claims.azp !== cfg.spaClientId) return { ok: false, status: 403, error: 'Caller application is not allowed' };
  const scopes = String(claims.scp || '').split(' ');
  if (!scopes.includes(REQUIRED_SCOPE)) return { ok: false, status: 403, error: 'Missing required scope' };
  if (String(claims.oid || '').toLowerCase() !== cfg.ownerOid) return { ok: false, status: 403, error: 'This gateway serves a different role owner' };
  return { ok: true, claims };
}

// ---------- Azure AI Search ----------
async function searchTickets(query, semantic) {
  const token = await getMsiToken('https://search.azure.com/');
  const body = Object.assign(
    { search: String(query || ''), searchFields: 'ticketText', select: 'ticketId', top: 20 },
    semantic ? { queryType: 'semantic', semanticConfiguration: 'ticket-semantic' } : { queryType: 'simple' }
  );
  const r = await httpsJson('POST', `https://${cfg.searchService}.search.windows.net/indexes/ticket-text/docs/search?api-version=2024-07-01`,
    { Authorization: `Bearer ${token}` }, body, 15000);
  if (r.status !== 200 || !r.json || !Array.isArray(r.json.value)) throw new Error(`Search returned HTTP ${r.status}`);
  return r.json.value;
}

// ---------- Azure SQL (tedious, access token from managed identity) ----------
async function callGateway(payloadObj) {
  const { Connection, Request, TYPES } = require('tedious');
  const token = await getMsiToken('https://database.windows.net/');
  return new Promise((resolve, reject) => {
    const connection = new Connection({
      server: `${cfg.sqlServer}.database.windows.net`,
      authentication: { type: 'azure-active-directory-access-token', options: { token } },
      options: { database: cfg.sqlDatabase, encrypt: true, port: 1433, connectTimeout: 20000, requestTimeout: 120000, rowCollectionOnRequestCompletion: false }
    });
    let row = null;
    connection.on('error', (e) => reject(e));
    connection.connect((err) => {
      if (err) return reject(err);
      const request = new Request('api.usp_Gateway', (e) => {
        connection.close();
        if (e) return reject(e);
        if (!row) return reject(new Error('api.usp_Gateway returned no rows'));
        resolve(row);
      });
      request.addParameter('Payload', TYPES.NVarChar, JSON.stringify(payloadObj));
      request.on('row', (columns) => {
        if (row) return;
        row = {};
        for (const c of columns) row[c.metadata.colName] = c.value;
      });
      connection.callProcedure(request);
    });
  });
}

async function runSql(payloadObj, res) {
  const row = await callGateway(payloadObj);
  const status = Number(row.HttpStatus) || 500;
  res.writeHead(status, responseHeaders());
  res.end(row.ResponseJson || '{}');
}

// ---------- HTTP server ----------
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > MAX_BODY) { reject(Object.assign(new Error('Request too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const path = (req.url || '').split('?')[0];
  try {
    if (req.method === 'GET' && path === '/healthz') return send(res, 200, { status: 'ok' });
    if (path !== '/api/gateway') return send(res, 404, { error: 'Not found' });
    if (req.method === 'OPTIONS') {
      res.writeHead(204, responseHeaders({ 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Max-Age': '600' }));
      return res.end();
    }
    if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' });

    const auth = await validateToken(req.headers.authorization);
    if (!auth.ok) return send(res, auth.status, { error: auth.error });

    let body;
    try { body = JSON.parse(await readBody(req)); if (body === null || typeof body !== 'object' || Array.isArray(body)) throw new Error('not an object'); }
    catch (e) { return send(res, e.status || 400, { error: e.status === 413 ? 'Request too large' : 'Invalid request' }); }

    const isSearch = body.op === 'ticketSearch' && body.searchAction !== 'refresh';
    if (!isSearch) return await runSql(body, res);

    let results = null; let mode = 'Semantic';
    try { results = await searchTickets(body.query, true); }
    catch (e) {
      console.warn('Semantic search failed, falling back to lexical:', e.message);
      mode = 'Lexical';
      try { results = await searchTickets(body.query, false); } catch (e2) { console.error('Lexical search failed:', e2.message); }
    }
    if (!results) return send(res, 503, { error: 'Ticket search is temporarily unavailable. No candidate or impact result was counted.' });
    return await runSql(Object.assign({}, body, { searchResponse: results, searchMode: mode }), res);
  } catch (e) {
    console.error('Unhandled gateway error:', e && e.message);
    return send(res, 500, { error: 'Backend failed; consult the gateway logs' });
  }
});

if (require.main === module) {
  for (const k of ['tenantId', 'apiClientId', 'spaClientId', 'ownerOid', 'sqlServer', 'sqlDatabase', 'searchService', 'webOrigin']) {
    if (!cfg[k]) { console.error(`Missing configuration: ${k}`); }
  }
  server.listen(cfg.port, () => console.log(`Role Patrol gateway listening on ${cfg.port}`));
}
module.exports = { validateToken, cfg, server };
